// Real-time IP intelligence using ip-api.com (free, no API key required, supports HTTPS via pro
// but free tier is HTTP only — Deno edge can call HTTP).
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

interface IpApiResponse {
  status: string;
  message?: string;
  query: string;
  country?: string;
  countryCode?: string;
  region?: string;
  regionName?: string;
  city?: string;
  zip?: string;
  lat?: number;
  lon?: number;
  timezone?: string;
  isp?: string;
  org?: string;
  as?: string;
  hosting?: boolean;
  proxy?: boolean;
  mobile?: boolean;
  reverse?: string;
}

function isValidIPv4(ip: string) {
  const m = ip.match(/^(\d{1,3}\.){3}\d{1,3}$/);
  if (!m) return false;
  return ip.split(".").every(p => Number(p) >= 0 && Number(p) <= 255);
}

function isPrivate(ip: string) {
  return /^10\./.test(ip) || /^192\.168\./.test(ip) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(ip)
    || /^127\./.test(ip) || /^169\.254\./.test(ip);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { ip } = await req.json();
    const target = String(ip || "").trim();
    if (!isValidIPv4(target)) {
      return new Response(JSON.stringify({ error: "Invalid IPv4 address" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const fields = "status,message,query,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,hosting,proxy,mobile,reverse";
    const url = `http://ip-api.com/json/${target}?fields=${fields}`;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    let data: IpApiResponse;
    try {
      const res = await fetch(url, { signal: ctrl.signal });
      if (!res.ok) throw new Error(`ip-api returned ${res.status}`);
      data = await res.json();
    } finally {
      clearTimeout(timer);
    }

    if (data.status !== "success") {
      // Private / reserved ranges — return classification without external lookup
      if (isPrivate(target)) {
        return new Response(JSON.stringify({
          ip: target,
          riskLevel: "Low",
          category: "Internal / Private",
          confidence: 90,
          source: "RFC1918 classification",
          recommendation: "Internal address — investigate via host telemetry, not external feeds.",
          indicators: ["RFC1918 private range"],
          geo: null,
          network: null,
          flags: { proxy: false, hosting: false, mobile: false },
          lookupAt: new Date().toISOString(),
        }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ error: data.message || "Lookup failed" }), {
        status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Real-signal-based risk scoring
    const indicators: string[] = [];
    let score = 0;
    if (data.proxy) { score += 50; indicators.push("Proxy / VPN / Tor exit node"); }
    if (data.hosting) { score += 25; indicators.push("Datacenter / hosting infrastructure"); }
    if (data.mobile) { score += 5; indicators.push("Mobile carrier address"); }
    if (data.org && /tor|vpn|proxy|anon/i.test(data.org)) { score += 25; indicators.push(`Org name contains anonymizer keyword: ${data.org}`); }
    if (data.isp && /digitalocean|amazon|google|microsoft|hetzner|ovh|linode|vultr|contabo|alibaba/i.test(data.isp)) {
      indicators.push(`Cloud provider: ${data.isp}`);
    }

    let riskLevel: "Low" | "Medium" | "High" = "Low";
    if (score >= 50) riskLevel = "High";
    else if (score >= 20) riskLevel = "Medium";

    const confidence = Math.min(95, 40 + score);
    const category = data.proxy ? "Anonymizer" : data.hosting ? "Hosting / Cloud" : "Public Internet";
    const recommendation = riskLevel === "High"
      ? "Treat as untrusted ingress. Enforce MFA and inspect related authentication events."
      : riskLevel === "Medium"
        ? "Increase monitoring and correlate with firewall and authentication logs."
        : "No strong abuse signal. Continue passive monitoring.";

    if (indicators.length === 0) indicators.push("No anonymizer or hosting flags from upstream feed");

    return new Response(JSON.stringify({
      ip: data.query,
      riskLevel,
      category,
      confidence,
      source: "ip-api.com (real-time)",
      recommendation,
      indicators,
      geo: {
        country: data.country,
        countryCode: data.countryCode,
        region: data.regionName,
        city: data.city,
        zip: data.zip,
        lat: data.lat,
        lon: data.lon,
        timezone: data.timezone,
      },
      network: {
        isp: data.isp,
        org: data.org,
        asn: data.as,
        reverseDns: data.reverse,
      },
      flags: {
        proxy: !!data.proxy,
        hosting: !!data.hosting,
        mobile: !!data.mobile,
      },
      lookupAt: new Date().toISOString(),
    }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Lookup failed" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
