// Real-time web scraper edge function — fetches actual remote HTML server-side (no CORS).
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
];

function pickUA() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

async function fetchWithTimeout(url: string, ms: number): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, {
      signal: ctrl.signal,
      redirect: "follow",
      headers: {
        "User-Agent": pickUA(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
      },
    });
  } finally {
    clearTimeout(t);
  }
}

async function fetchHtml(url: string): Promise<{ html: string; status: number; finalUrl: string }> {
  // Direct fetch first
  try {
    const res = await fetchWithTimeout(url, 15000);
    const text = await res.text();
    if (res.ok && text && text.length > 50) {
      return { html: text, status: res.status, finalUrl: res.url || url };
    }
  } catch (_) { /* fall through */ }

  // Jina Reader fallback (returns plaintext markdown but we wrap as HTML)
  try {
    const sanitized = url.replace(/^https?:\/\//i, "");
    const res = await fetchWithTimeout(`https://r.jina.ai/http://${sanitized}`, 15000);
    if (res.ok) {
      const text = await res.text();
      const wrapped = `<html><head><title>${new URL(url).hostname}</title></head><body><pre>${text}</pre></body></html>`;
      return { html: wrapped, status: 200, finalUrl: url };
    }
  } catch (_) { /* ignore */ }

  throw new Error("All fetch strategies failed");
}

// Lightweight HTML extractor (no DOMParser in Deno edge).
function stripTags(s: string) {
  return s.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function decodeEntities(s: string) {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ");
}

function absoluteUrl(base: string, href: string) {
  try { return new URL(href, base).href; } catch { return href; }
}

function extract(url: string, html: string) {
  // Strip script/style/noscript blocks for cleaner parsing
  const cleaned = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ");

  const titleMatch = cleaned.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? decodeEntities(stripTags(titleMatch[1])).slice(0, 200) : new URL(url).hostname;

  const descMatch = cleaned.match(/<meta[^>]+name=["']description["'][^>]*content=["']([^"']+)["']/i)
    || cleaned.match(/<meta[^>]+property=["']og:description["'][^>]*content=["']([^"']+)["']/i);
  const description = descMatch ? decodeEntities(descMatch[1]).slice(0, 400) : "";

  const headings: { level: string; text: string }[] = [];
  const seenH = new Set<string>();
  const headingRe = /<(h[1-6])[^>]*>([\s\S]*?)<\/\1>/gi;
  let hm: RegExpExecArray | null;
  while ((hm = headingRe.exec(cleaned)) && headings.length < 100) {
    const text = decodeEntities(stripTags(hm[2])).slice(0, 200);
    const key = `${hm[1]}:${text}`;
    if (text && !seenH.has(key)) {
      seenH.add(key);
      headings.push({ level: hm[1].toUpperCase(), text });
    }
  }

  const paragraphs: string[] = [];
  const seenP = new Set<string>();
  const pRe = /<p[^>]*>([\s\S]*?)<\/p>/gi;
  let pm: RegExpExecArray | null;
  while ((pm = pRe.exec(cleaned)) && paragraphs.length < 100) {
    const text = decodeEntities(stripTags(pm[1])).slice(0, 500);
    if (text.length > 20 && !seenP.has(text)) {
      seenP.add(text);
      paragraphs.push(text);
    }
  }

  const links: { href: string; text: string }[] = [];
  const seenL = new Set<string>();
  const aRe = /<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let am: RegExpExecArray | null;
  while ((am = aRe.exec(cleaned)) && links.length < 100) {
    const href = am[1];
    if (!href || href.startsWith("#") || href.startsWith("javascript:") || href.startsWith("mailto:")) continue;
    const abs = absoluteUrl(url, href);
    if (seenL.has(abs)) continue;
    seenL.add(abs);
    const text = decodeEntities(stripTags(am[2])).slice(0, 100) || "(no text)";
    links.push({ href: abs, text });
  }

  const images: { src: string; alt: string }[] = [];
  const seenI = new Set<string>();
  const imgRe = /<img[^>]+src=["']([^"']+)["'][^>]*>/gi;
  let im: RegExpExecArray | null;
  while ((im = imgRe.exec(cleaned)) && images.length < 100) {
    const src = absoluteUrl(url, im[1]);
    if (seenI.has(src)) continue;
    seenI.add(src);
    const altMatch = im[0].match(/alt=["']([^"']*)["']/i);
    images.push({ src, alt: altMatch ? decodeEntities(altMatch[1]) : "" });
  }

  const forms: { action: string; method: string; inputs: string[] }[] = [];
  const formRe = /<form([^>]*)>([\s\S]*?)<\/form>/gi;
  let fm: RegExpExecArray | null;
  while ((fm = formRe.exec(cleaned)) && forms.length < 30) {
    const attrs = fm[1];
    const inner = fm[2];
    const actionM = attrs.match(/action=["']([^"']*)["']/i);
    const methodM = attrs.match(/method=["']([^"']*)["']/i);
    const inputs: string[] = [];
    const inpRe = /<(input|textarea|select|button)([^>]*)>/gi;
    let inpm: RegExpExecArray | null;
    while ((inpm = inpRe.exec(inner))) {
      const tag = inpm[1].toLowerCase();
      const a = inpm[2];
      const nameM = a.match(/name=["']([^"']*)["']/i) || a.match(/id=["']([^"']*)["']/i);
      const typeM = a.match(/type=["']([^"']*)["']/i);
      inputs.push(`${nameM ? nameM[1] : "(unnamed)"} (${typeM ? typeM[1] : tag})`);
    }
    forms.push({
      action: absoluteUrl(url, actionM ? actionM[1] : url),
      method: (methodM ? methodM[1] : "GET").toUpperCase(),
      inputs,
    });
  }

  const bodyText = stripTags(cleaned);
  const emails = [...new Set(bodyText.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [])].slice(0, 20);

  const findings: string[] = [];
  const targetHost = (() => { try { return new URL(url).hostname; } catch { return ""; } })();
  const externalLinks = links.filter(l => { try { return new URL(l.href).hostname !== targetHost; } catch { return false; } }).length;
  if (forms.some(f => f.inputs.some(i => /\(password\)/i.test(i)))) findings.push("Contains credential collection form");
  if (url.startsWith("http://") && forms.length > 0) findings.push("Page uses HTTP with form submission — credentials may be exposed");
  if (externalLinks > 20) findings.push(`Large number of outbound links (${externalLinks}) detected`);
  if (paragraphs.length === 0 && headings.length === 0) findings.push("Low extractable content — page may rely heavily on client-side rendering");
  if (!description) findings.push("Missing meta description (SEO weakness)");

  return {
    url,
    title,
    description,
    headings,
    paragraphs,
    links,
    images,
    forms,
    emails,
    findings,
    scrapedAt: new Date().toISOString(),
    source: "live" as const,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { url } = await req.json();
    if (!url || typeof url !== "string") {
      return new Response(JSON.stringify({ error: "Missing 'url' in body" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    let target = url.trim();
    if (!/^https?:\/\//i.test(target)) target = `https://${target}`;
    try { new URL(target); } catch {
      return new Response(JSON.stringify({ error: "Invalid URL" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const start = Date.now();
    const { html, status, finalUrl } = await fetchHtml(target);
    const data = extract(finalUrl, html);
    const elapsed = Date.now() - start;

    return new Response(JSON.stringify({ ...data, httpStatus: status, elapsedMs: elapsed, bytes: html.length }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
