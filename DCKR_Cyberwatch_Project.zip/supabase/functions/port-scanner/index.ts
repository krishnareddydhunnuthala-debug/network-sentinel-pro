import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const PORT_SERVICES: Record<number, string> = {
  20: "FTP-Data", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
  53: "DNS", 80: "HTTP", 110: "POP3", 111: "RPC", 135: "MS-RPC",
  139: "NetBIOS", 143: "IMAP", 161: "SNMP", 389: "LDAP", 443: "HTTPS",
  445: "SMB", 465: "SMTPS", 587: "SMTP-SUB", 636: "LDAPS",
  993: "IMAPS", 995: "POP3S", 1433: "MSSQL", 1521: "Oracle",
  2049: "NFS", 2375: "Docker", 2376: "Docker-TLS", 27017: "MongoDB",
  3000: "Dev Server", 3306: "MySQL", 3389: "RDP", 5000: "UPnP",
  5432: "PostgreSQL", 5900: "VNC", 5984: "CouchDB", 6379: "Redis",
  8000: "HTTP-Alt", 8080: "HTTP-Proxy", 8443: "HTTPS-Alt",
  8888: "HTTP-Alt", 9000: "Kibana/Misc", 9200: "Elasticsearch",
  11211: "Memcached", 25565: "Minecraft", 50000: "SAP",
};

interface PortResult {
  port: number;
  status: "open" | "closed" | "filtered";
  service: string;
  responseTimeMs?: number;
}

interface RequestBody {
  host?: unknown;
  startPort?: unknown;
  endPort?: unknown;
  ports?: unknown;
  concurrency?: unknown;
  timeoutMs?: unknown;
}

function serviceName(port: number) {
  return PORT_SERVICES[port] || "Unknown";
}

function isIpv4(host: string) {
  const parts = host.split('.');
  if (parts.length !== 4) return false;
  return parts.every(part => /^\d+$/.test(part) && Number(part) >= 0 && Number(part) <= 255);
}

function normalizeHost(raw: string): string {
  let host = raw.trim();
  // Strip protocol
  host = host.replace(/^[a-z]+:\/\//i, "");
  // Strip path/query/fragment
  host = host.split("/")[0].split("?")[0].split("#")[0];
  // Strip user info
  host = host.split("@").pop() || host;
  // Strip port (handle IPv6 in brackets)
  if (host.startsWith("[")) {
    const end = host.indexOf("]");
    if (end !== -1) host = host.slice(1, end);
  } else {
    host = host.split(":")[0];
  }
  return host.toLowerCase();
}

function isAllowedHost(host: string): boolean {
  if (!host || host.length > 253) return false;
  if (/^(localhost|0\.0\.0\.0)$/i.test(host)) return false;
  if (/^(127\.|::1$)/i.test(host)) return false;
  if (/^(10\.|192\.168\.|169\.254\.)/.test(host)) return false;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) return false;
  if (isIpv4(host)) return true;
  return /^[a-z0-9.-]+$/i.test(host) && /\./.test(host);
}

function hostValidationMessage(host: string): string {
  if (!host) return "Host is required";
  if (/^(localhost|0\.0\.0\.0|::1)$/i.test(host) || /^(127\.)/i.test(host)) {
    return "Localhost and loopback targets are not allowed. Use a public hostname or IP.";
  }
  if (/^(10\.|192\.168\.|169\.254\.)/i.test(host) || /^172\.(1[6-9]|2\d|3[0-1])\./i.test(host)) {
    return "Private network targets are not allowed. Use a public hostname or IP.";
  }
  return "Invalid or disallowed host. Use a public hostname or IP.";
}

function normalizePorts(body: RequestBody): number[] {
  const rawPorts = Array.isArray(body.ports)
    ? body.ports.map(value => Number(value)).filter(value => Number.isInteger(value) && value >= 1 && value <= 65535)
    : [];

  if (rawPorts.length > 0) {
    return [...new Set(rawPorts)].sort((a, b) => a - b);
  }

  const startPort = Math.max(1, Math.min(65535, Number(body.startPort) || 1));
  const endPort = Math.max(startPort, Math.min(65535, Number(body.endPort) || 1024));
  return Array.from({ length: endPort - startPort + 1 }, (_, index) => startPort + index);
}

async function probePort(host: string, port: number, timeoutMs: number): Promise<PortResult> {
  const start = Date.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);

  try {
    const conn = await Deno.connect({ hostname: host, port, signal: ctrl.signal } as Deno.ConnectOptions & { signal: AbortSignal });
    const elapsed = Date.now() - start;
    try {
      conn.close();
    } catch {
      // Connection is already closed.
    }
    return { port, status: "open", service: serviceName(port), responseTimeMs: elapsed };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (/refused/i.test(message)) {
      return { port, status: "closed", service: serviceName(port) };
    }
    return { port, status: "filtered", service: serviceName(port) };
  } finally {
    clearTimeout(timer);
  }
}

async function runConcurrent(items: number[], concurrency: number, worker: (item: number) => Promise<PortResult>) {
  const results = new Array<PortResult>(items.length);
  let nextIndex = 0;

  const runners = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (true) {
      const currentIndex = nextIndex;
      nextIndex += 1;
      if (currentIndex >= items.length) return;
      results[currentIndex] = await worker(items[currentIndex]);
    }
  });

  await Promise.all(runners);
  return results;
}

Deno.serve(async req => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json() as RequestBody;
    const host = normalizeHost(String(body.host || ""));
    const concurrency = Math.max(10, Math.min(500, Number(body.concurrency) || 250));
    const timeoutMs = Math.max(150, Math.min(3000, Number(body.timeoutMs) || 600));
    const ports = normalizePorts(body);

    if (!isAllowedHost(host)) {
      return new Response(JSON.stringify({ error: hostValidationMessage(host) }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (ports.length === 0) {
      return new Response(JSON.stringify({ error: "No valid ports supplied" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (ports.length > 500) {
      return new Response(JSON.stringify({ error: "Too many ports in one batch (max 500)" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const startedAt = Date.now();
    const results = await runConcurrent(ports, concurrency, port => probePort(host, port, timeoutMs));
    const elapsedMs = Date.now() - startedAt;
    const sorted = [...results].sort((a, b) => a.port - b.port);

    const summary = {
      host,
      startPort: sorted[0]?.port ?? 0,
      endPort: sorted[sorted.length - 1]?.port ?? 0,
      total: sorted.length,
      open: sorted.filter(result => result.status === "open").length,
      closed: sorted.filter(result => result.status === "closed").length,
      filtered: sorted.filter(result => result.status === "filtered").length,
      elapsedMs,
      scannedAt: new Date().toISOString(),
    };

    return new Response(JSON.stringify({ summary, results: sorted }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Scan failed" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
