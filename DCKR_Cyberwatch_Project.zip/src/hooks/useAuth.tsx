import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

type AppRole = 'admin' | 'viewer';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  role: AppRole | null;
  isAdmin: boolean;
  loading: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);

  const loadRole = useCallback(async (uid: string | undefined) => {
    if (!uid) { setRole(null); return; }
    const { data } = await supabase.from('user_roles').select('role').eq('user_id', uid);
    if (data && data.length > 0) {
      const roles = data.map(r => r.role as AppRole);
      setRole(roles.includes('admin') ? 'admin' : 'viewer');
    } else {
      setRole('viewer');
    }
  }, []);

  useEffect(() => {
    // 1) Subscribe FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      setUser(newSession?.user ?? null);
      // Defer async role lookup to avoid deadlock with auth callback
      if (newSession?.user) {
        setTimeout(() => { loadRole(newSession.user.id); }, 0);
      } else {
        setRole(null);
      }
    });

    // 2) Then check existing
    supabase.auth.getSession().then(({ data: { session: existing } }) => {
      setSession(existing);
      setUser(existing?.user ?? null);
      if (existing?.user) loadRole(existing.user.id);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [loadRole]);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null); setUser(null); setRole(null);
  }, []);

  return (
    <AuthContext.Provider value={{ session, user, role, isAdmin: role === 'admin', loading, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
