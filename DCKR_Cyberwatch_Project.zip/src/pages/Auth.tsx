import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { z } from 'zod';
import { Shield, Loader2, Mail, Lock, User as UserIcon } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable/index';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

const emailSchema = z.string().trim().email({ message: 'Enter a valid email' }).max(255);
const passwordSchema = z.string().min(8, { message: 'Password must be at least 8 characters' }).max(72);
const nameSchema = z.string().trim().min(1, { message: 'Name is required' }).max(80);

type StrengthLevel = 'empty' | 'weak' | 'medium' | 'strong';

function evaluatePasswordStrength(pw: string): { level: StrengthLevel; score: number; label: string } {
  if (!pw) return { level: 'empty', score: 0, label: '' };
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  if (pw.length < 8) return { level: 'weak', score, label: 'Weak' };
  if (score <= 2) return { level: 'weak', score, label: 'Weak' };
  if (score === 3 || score === 4) return { level: 'medium', score, label: 'Medium' };
  return { level: 'strong', score, label: 'Strong' };
}

export default function AuthPage() {
  const navigate = useNavigate();
  const { session, loading } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && session) navigate('/', { replace: true });
  }, [session, loading, navigate]);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      emailSchema.parse(email);
      passwordSchema.parse(password);
      if (mode === 'signup') nameSchema.parse(displayName);
    } catch (err) {
      if (err instanceof z.ZodError) { toast.error(err.errors[0].message); return; }
    }

    setBusy(true);
    try {
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: {
            emailRedirectTo: `${window.location.origin}/`,
            data: { display_name: displayName },
          },
        });
        if (error) throw error;
        toast.success('Account created — signing you in...');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success('Welcome back');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Authentication failed';
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  };

  const handleGoogle = async () => {
    setBusy(true);
    try {
      const result = await lovable.auth.signInWithOAuth('google', { redirect_uri: window.location.origin });
      if (result.error) throw result.error;
      // result.redirected -> browser navigates to Google
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google sign-in failed';
      toast.error(msg);
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-3 mb-6">
          <div className="p-2.5 rounded-lg bg-primary/10 pulse-glow">
            <Shield className="w-7 h-7 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground cyber-glow-text">DC Krishna Reddy Cyberwatch</h1>
            <p className="text-[10px] text-muted-foreground tracking-wider uppercase">Intelligence System v2.0</p>
          </div>
        </div>

        <div className="cyber-card p-6">
          <div className="flex gap-1 mb-5 p-1 bg-secondary/40 rounded-md">
            <button
              onClick={() => setMode('signin')}
              className={`flex-1 py-1.5 rounded text-sm font-medium transition ${mode === 'signin' ? 'bg-card text-foreground shadow' : 'text-muted-foreground'}`}
            >Sign In</button>
            <button
              onClick={() => setMode('signup')}
              className={`flex-1 py-1.5 rounded text-sm font-medium transition ${mode === 'signup' ? 'bg-card text-foreground shadow' : 'text-muted-foreground'}`}
            >Sign Up</button>
          </div>

          <form onSubmit={handleEmailSubmit} className="space-y-3">
            {mode === 'signup' && (
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Display Name</label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={e => setDisplayName(e.target.value)}
                    placeholder="Analyst Name"
                    className="w-full bg-background border border-border rounded-md pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
              </div>
            )}
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full bg-background border border-border rounded-md pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  autoComplete="email"
                />
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground block mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  className="w-full bg-background border border-border rounded-md pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                />
              </div>
              {mode === 'signup' && (() => {
                const s = evaluatePasswordStrength(password);
                if (s.level === 'empty') return null;
                const colorMap = {
                  weak: { bar: 'bg-red-500', text: 'text-red-500', width: 'w-1/3' },
                  medium: { bar: 'bg-yellow-500', text: 'text-yellow-500', width: 'w-2/3' },
                  strong: { bar: 'bg-green-500', text: 'text-green-500', width: 'w-full' },
                }[s.level];
                return (
                  <div className="mt-1.5">
                    <div className="h-1 w-full bg-secondary/60 rounded overflow-hidden">
                      <div className={`h-full ${colorMap.bar} ${colorMap.width} transition-all`} />
                    </div>
                    <p className={`text-[10px] mt-1 font-medium ${colorMap.text}`}>
                      Password strength: {s.label}
                    </p>
                  </div>
                );
              })()}
            </div>

            <button
              type="submit"
              disabled={busy}
              className="w-full py-2.5 bg-primary text-primary-foreground rounded-md font-medium text-sm hover:bg-primary/90 disabled:opacity-50 transition flex items-center justify-center gap-2"
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {mode === 'signup' ? 'Create Account' : 'Sign In'}
            </button>
          </form>

          <div className="my-4 flex items-center gap-3 text-[11px] text-muted-foreground">
            <div className="flex-1 h-px bg-border" />
            <span>OR</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <button
            onClick={handleGoogle}
            disabled={busy}
            className="w-full py-2.5 border border-border bg-card hover:bg-secondary text-foreground rounded-md font-medium text-sm transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
          </button>

          <p className="text-[11px] text-muted-foreground text-center mt-5">
            Protected dashboard — sign in to access scanner, packet analyzer, and reports.
          </p>
        </div>
      </div>
    </div>
  );
}
