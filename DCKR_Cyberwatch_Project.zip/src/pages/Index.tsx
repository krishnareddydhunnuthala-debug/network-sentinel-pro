import { useState, useCallback } from 'react';
import DashboardLayout from '@/components/DashboardLayout';
import OverviewModule from '@/components/OverviewModule';
import LogAnalyzerModule from '@/components/LogAnalyzerModule';
import NetworkScannerModule from '@/components/NetworkScannerModule';
import PacketAnalyzerModule from '@/components/PacketAnalyzerModule';
import ThreatIntelModule from '@/components/ThreatIntelModule';
import WebScraperModule from '@/components/WebScraperModule';
import ReportModule from '@/components/ReportModule';
import IDSModule from '@/components/IDSModule';
import { type LogEntry, type IPAnalysis, type PortResult, type PacketData, type ThreatEntry } from '@/lib/cyberUtils';

const Index = () => {
  const [activeModule, setActiveModule] = useState('overview');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [ipAnalysis, setIpAnalysis] = useState<IPAnalysis[]>([]);
  const [portScan, setPortScan] = useState<{ target: string; results: PortResult[] } | null>(null);
  const [packets, setPackets] = useState<PacketData[]>([]);
  const [threats, setThreats] = useState<ThreatEntry[]>([]);

  const handleLogAnalysis = useCallback((l: LogEntry[], ips: IPAnalysis[]) => {
    setLogs(l);
    setIpAnalysis(ips);
  }, []);

  const handleScan = useCallback((target: string, results: PortResult[]) => {
    setPortScan({ target, results });
  }, []);

  const handleCapture = useCallback((pkts: PacketData[]) => {
    setPackets(pkts);
  }, []);

  const handleThreatUpdate = useCallback((t: ThreatEntry[]) => {
    setThreats(t);
  }, []);

  const stats = {
    logsAnalyzed: logs.length,
    threatsDetected: ipAnalysis.filter(ip => ip.riskLevel === 'High').length + packets.filter(p => p.anomaly).length,
    portsScanned: portScan?.results.length || 0,
    packetsInspected: packets.length,
  };

  return (
    <DashboardLayout activeModule={activeModule} onModuleChange={setActiveModule}>
      {activeModule === 'overview' && <OverviewModule stats={stats} />}
      {activeModule === 'logs' && <LogAnalyzerModule onAnalysis={handleLogAnalysis} />}
      {activeModule === 'scanner' && <NetworkScannerModule onScan={handleScan} />}
      {activeModule === 'packets' && <PacketAnalyzerModule onCapture={handleCapture} />}
      {activeModule === 'threats' && <ThreatIntelModule onUpdate={handleThreatUpdate} />}
      {activeModule === 'ids' && <IDSModule logs={logs} ipAnalysis={ipAnalysis} packets={packets} />}
      {activeModule === 'scraper' && <WebScraperModule />}
      {activeModule === 'reports' && (
        <ReportModule logs={logs} ipAnalysis={ipAnalysis} portScan={portScan} packets={packets} threats={threats} />
      )}
    </DashboardLayout>
  );
};

export default Index;
