// Cyber utilities — log parsing, packet inspection, and report generation.
// All data sources here are derived from real user input or live browser telemetry —
// no simulated/seeded threat data.

export interface LogEntry {
  timestamp: string;
  ip: string;
  action: string;
  status: 'success' | 'failed' | 'warning';
  details: string;
}

export interface IPAnalysis {
  ip: string;
  count: number;
  failedAttempts: number;
  successAttempts: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  isSuspicious: boolean;
}

export interface PortResult {
  port: number;
  status: 'open' | 'closed' | 'filtered';
  service: string;
  responseTimeMs?: number;
}

export interface PacketData {
  id: number;
  timestamp: string;
  source: string;
  destination: string;
  protocol: string;
  size: number;
  payload: string;
  flags: string[];
  anomaly: string | null;
  sourcePort?: number;
  destinationPort?: number;
  severity?: 'info' | 'low' | 'medium' | 'high';
  category?: string;
  matchedRules?: string[];
  flowLabel?: string;
}

export interface ThreatEntry {
  ip: string;
  riskLevel: 'Low' | 'Medium' | 'High';
  category: string;
  lastSeen?: string;
  reportCount?: number;
  confidence?: number;
  source?: string;
  recommendation?: string;
  indicators?: string[];
  geo?: {
    country?: string;
    countryCode?: string;
    region?: string;
    city?: string;
    zip?: string;
    lat?: number;
    lon?: number;
    timezone?: string;
  } | null;
  network?: {
    isp?: string;
    org?: string;
    asn?: string;
    reverseDns?: string;
  } | null;
  flags?: { proxy?: boolean; hosting?: boolean; mobile?: boolean };
}

const SEVERITY_ORDER: Record<NonNullable<PacketData['severity']>, number> = {
  info: 0, low: 1, medium: 2, high: 3,
};

const PAYLOAD_RULES: Array<{
  id: string;
  pattern: RegExp;
  anomaly: string;
  category: string;
  severity: NonNullable<PacketData['severity']>;
}> = [
  { id: 'sql-union', pattern: /union\s+select/i, anomaly: 'SQL Injection Attempt', category: 'Web Attack', severity: 'high' },
  { id: 'sql-tautology', pattern: /(?:'|")\s*or\s+\d+\s*=\s*\d+/i, anomaly: 'SQL Injection Attempt', category: 'Web Attack', severity: 'high' },
  { id: 'sql-drop', pattern: /drop\s+table/i, anomaly: 'Destructive SQL Payload', category: 'Database Attack', severity: 'high' },
  { id: 'xss-script', pattern: /<script|javascript:/i, anomaly: 'XSS Attempt', category: 'Web Attack', severity: 'high' },
  { id: 'command-exec', pattern: /(?:cmd=|wget\s+http|curl\s+http|eval\()/i, anomaly: 'Command Injection Attempt', category: 'Remote Execution', severity: 'high' },
  { id: 'path-traversal', pattern: /\.\.\/|\/etc\/passwd/i, anomaly: 'Path Traversal Probe', category: 'Reconnaissance', severity: 'medium' },
  { id: 'auth-failure', pattern: /failed password|authentication failed|invalid user/i, anomaly: 'Credential Attack Activity', category: 'Credential Attack', severity: 'medium' },
  { id: 'tracker-pixel', pattern: /(?:gtag|google-analytics|doubleclick|facebook\.com\/tr)/i, anomaly: 'Tracking Pixel', category: 'Privacy', severity: 'low' },
];

export function parseLogs(rawText: string): LogEntry[] {
  const lines = rawText.split('\n').filter(l => l.trim());
  const ipRegex = /\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b/;
  const timestampRegex = /\[?([\d\-/:T. ]+)\]?/;

  return lines.map(line => {
    const ipMatch = line.match(ipRegex);
    const timeMatch = line.match(timestampRegex);
    const isFailed = /fail|denied|error|unauthorized|invalid|block/i.test(line);
    const isWarning = /warn|suspicious|unusual|alert/i.test(line);

    return {
      timestamp: timeMatch?.[1]?.trim() || new Date().toISOString(),
      ip: ipMatch?.[1] || 'unknown',
      action: extractAction(line),
      status: isFailed ? 'failed' : isWarning ? 'warning' : 'success',
      details: line.trim(),
    };
  });
}

function extractAction(line: string): string {
  if (/login|auth/i.test(line)) return 'Authentication';
  if (/scan|probe/i.test(line)) return 'Port Scan';
  if (/download|upload|transfer/i.test(line)) return 'File Transfer';
  if (/request|GET|POST|PUT|DELETE/i.test(line)) return 'HTTP Request';
  if (/connect/i.test(line)) return 'Connection';
  return 'System Event';
}

export function analyzeIPs(entries: LogEntry[]): IPAnalysis[] {
  const ipMap = new Map<string, { total: number; failed: number; success: number }>();

  entries.forEach(e => {
    if (e.ip === 'unknown') return;
    const existing = ipMap.get(e.ip) || { total: 0, failed: 0, success: 0 };
    existing.total++;
    if (e.status === 'failed') existing.failed++;
    else existing.success++;
    ipMap.set(e.ip, existing);
  });

  return Array.from(ipMap.entries()).map(([ip, data]) => {
    const failRatio = data.failed / data.total;
    let riskLevel: 'Low' | 'Medium' | 'High' = 'Low';
    if (failRatio > 0.7 || data.failed > 10) riskLevel = 'High';
    else if (failRatio > 0.4 || data.failed > 5) riskLevel = 'Medium';

    return {
      ip,
      count: data.total,
      failedAttempts: data.failed,
      successAttempts: data.success,
      riskLevel,
      isSuspicious: riskLevel !== 'Low',
    };
  }).sort((a, b) => b.failedAttempts - a.failedAttempts);
}

export function inspectPacket(packet: PacketData): PacketData {
  const matchedRules = [...new Set(packet.matchedRules ?? [])];
  let anomaly = packet.anomaly;
  let category = packet.category ?? 'Normal Traffic';
  let severity = packet.severity ?? 'info';

  for (const rule of PAYLOAD_RULES) {
    if (rule.pattern.test(packet.payload) || rule.pattern.test(packet.destination)) {
      anomaly = rule.anomaly;
      category = rule.category;
      severity = SEVERITY_ORDER[rule.severity] > SEVERITY_ORDER[severity] ? rule.severity : severity;
      matchedRules.push(rule.id);
    }
  }

  if (packet.size > 250_000) {
    anomaly = anomaly ?? 'Unusually Large Transfer';
    category = category === 'Normal Traffic' ? 'Bulk Transfer' : category;
    severity = SEVERITY_ORDER.low > SEVERITY_ORDER[severity] ? 'low' : severity;
    matchedRules.push('large-payload');
  }

  return {
    ...packet,
    anomaly,
    category,
    severity,
    matchedRules: [...new Set(matchedRules)],
  };
}

export function analyzePacketStream(packets: PacketData[]): PacketData[] {
  const inspected = packets.map(inspectPacket);
  const destMap = new Map<string, Set<string>>();

  inspected.forEach(packet => {
    const targets = destMap.get(packet.source) ?? new Set<string>();
    targets.add(packet.destination);
    destMap.set(packet.source, targets);
  });

  return inspected.map(packet => {
    const matchedRules = [...(packet.matchedRules ?? [])];
    let anomaly = packet.anomaly;
    let category = packet.category ?? 'Normal Traffic';
    let severity = packet.severity ?? 'info';

    const uniqueTargets = destMap.get(packet.source)?.size ?? 0;
    if (uniqueTargets >= 15) {
      anomaly = anomaly ?? 'High-Fanout Source';
      category = category === 'Normal Traffic' ? 'Behavioral Anomaly' : category;
      severity = SEVERITY_ORDER.medium > SEVERITY_ORDER[severity] ? 'medium' : severity;
      matchedRules.push('high-fanout-correlation');
    }

    return { ...packet, anomaly, category, severity, matchedRules: [...new Set(matchedRules)] };
  });
}

/**
 * Convert a real PerformanceResourceTiming entry from the browser into a PacketData record.
 * This is the source of REAL packet data — every fetch/xhr/script/image the page loads.
 */
export function packetFromResourceTiming(entry: PerformanceResourceTiming, id: number): PacketData {
  let host = entry.name;
  let protocol = 'HTTP';
  let port: number | undefined;
  try {
    const u = new URL(entry.name);
    host = u.hostname;
    protocol = u.protocol === 'https:' ? 'HTTPS' : u.protocol === 'wss:' ? 'WSS' : u.protocol === 'ws:' ? 'WS' : 'HTTP';
    port = u.port ? Number(u.port) : (u.protocol === 'https:' || u.protocol === 'wss:') ? 443 : 80;
  } catch { /* keep defaults */ }

  const size = entry.transferSize || entry.encodedBodySize || entry.decodedBodySize || 0;
  const flags: string[] = [];
  if (entry.transferSize === 0 && entry.decodedBodySize > 0) flags.push('CACHED');
  if (entry.nextHopProtocol) flags.push(entry.nextHopProtocol.toUpperCase());

  return inspectPacket({
    id,
    timestamp: new Date(performance.timeOrigin + entry.startTime).toISOString(),
    source: window.location.hostname || 'browser',
    destination: host,
    protocol,
    size,
    payload: entry.name,
    flags,
    anomaly: null,
    destinationPort: port,
    severity: 'info',
    category: entry.initiatorType ? `Resource: ${entry.initiatorType}` : 'Network Activity',
    flowLabel: entry.initiatorType || 'resource',
    matchedRules: [],
  });
}

export function generateReport(data: {
  logs?: LogEntry[];
  ipAnalysis?: IPAnalysis[];
  portScan?: { target: string; results: PortResult[] };
  packets?: PacketData[];
  threats?: ThreatEntry[];
}) {
  const anomalies = data.packets?.filter(p => p.anomaly) || [];
  const highRiskIPs = data.ipAnalysis?.filter(ip => ip.riskLevel === 'High') || [];
  const packetCategories = (data.packets || []).reduce<Record<string, number>>((acc, packet) => {
    const key = packet.category || 'Normal Traffic';
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  return {
    reportId: `RPT-${Date.now()}`,
    generatedAt: new Date().toISOString(),
    summary: {
      totalLogsAnalyzed: data.logs?.length || 0,
      uniqueIPs: data.ipAnalysis?.length || 0,
      highRiskIPs: highRiskIPs.length,
      openPorts: data.portScan?.results.filter(p => p.status === 'open').length || 0,
      packetsInspected: data.packets?.length || 0,
      anomaliesDetected: anomalies.length,
      threatsIdentified: data.threats?.filter(t => t.riskLevel === 'High').length || 0,
      suspiciousSources: new Set(anomalies.map(packet => packet.source)).size,
    },
    detailedFindings: {
      suspiciousIPs: highRiskIPs,
      anomalousPackets: anomalies.slice(0, 50),
      openServices: data.portScan?.results.filter(p => p.status === 'open') || [],
      threatIntelligence: data.threats || [],
      packetCategories,
    },
  };
}

export function isValidIPv4(ip: string) {
  const trimmed = ip.trim();
  const match = trimmed.match(/^(\d{1,3}\.){3}\d{1,3}$/);
  if (!match) return false;
  return trimmed.split('.').every(part => Number(part) >= 0 && Number(part) <= 255);
}
