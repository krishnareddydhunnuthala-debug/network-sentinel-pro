import { useState, useCallback, useMemo, useRef, useTransition } from 'react';
import { Upload, Search, AlertCircle, CheckCircle, XCircle, FileText, Zap, Filter } from 'lucide-react';
import { parseLogs, analyzeIPs, type LogEntry, type IPAnalysis } from '@/lib/cyberUtils';

interface LogAnalyzerProps {
  onAnalysis: (logs: LogEntry[], ips: IPAnalysis[]) => void;
}

const VISIBLE_ROWS = 200;

export default function LogAnalyzerModule({ onAnalysis }: LogAnalyzerProps) {
  const [rawLog, setRawLog] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [ipAnalysis, setIpAnalysis] = useState<IPAnalysis[]>([]);
  const [analyzed, setAnalyzed] = useState(false);
  const [fileName, setFileName] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'failed' | 'warning' | 'success'>('all');
  const [parseTime, setParseTime] = useState(0);
  const [isPending, startTransition] = useTransition();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const runAnalysis = useCallback((text: string) => {
    const t0 = performance.now();
    startTransition(() => {
      const parsed = parseLogs(text);
      const analysis = analyzeIPs(parsed);
      setLogs(parsed);
      setIpAnalysis(analysis);
      setAnalyzed(true);
      setParseTime(performance.now() - t0);
      onAnalysis(parsed, analysis);
    });
  }, [onAnalysis]);

  const handleAnalyze = useCallback(() => {
    if (!rawLog.trim()) return;
    runAnalysis(rawLog);
  }, [rawLog, runAnalysis]);

  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = (ev.target?.result as string) || '';
      setRawLog(text);
      runAnalysis(text);
    };
    reader.readAsText(file);
  }, [runAnalysis]);

  const clearAll = useCallback(() => {
    setRawLog('');
    setLogs([]);
    setIpAnalysis([]);
    setAnalyzed(false);
    setFileName('');
    setParseTime(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
    onAnalysis([], []);
  }, [onAnalysis]);

  const statusIcon = (status: string) => {
    if (status === 'failed') return <XCircle className="w-3.5 h-3.5 text-destructive shrink-0" />;
    if (status === 'warning') return <AlertCircle className="w-3.5 h-3.5 text-warning shrink-0" />;
    return <CheckCircle className="w-3.5 h-3.5 text-primary shrink-0" />;
  };

  const riskColor = (level: string) => {
    if (level === 'High') return 'text-destructive';
    if (level === 'Medium') return 'text-warning';
    return 'text-primary';
  };

  const stats = useMemo(() => ({
    failed: logs.filter(l => l.status === 'failed').length,
    warning: logs.filter(l => l.status === 'warning').length,
    success: logs.filter(l => l.status === 'success').length,
    suspicious: ipAnalysis.filter(i => i.isSuspicious).length,
  }), [logs, ipAnalysis]);

  const filteredLogs = useMemo(() => {
    if (statusFilter === 'all') return logs;
    return logs.filter(l => l.status === statusFilter);
  }, [logs, statusFilter]);

  const visibleLogs = useMemo(() => filteredLogs.slice(0, VISIBLE_ROWS), [filteredLogs]);

  return (
    <div>
      <div className="flex items-start justify-between mb-6 gap-3 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-1 cyber-glow-text">Log Analyzer</h2>
          <p className="text-muted-foreground text-sm">Upload your real server logs — analysis runs instantly on file load</p>
        </div>
        {analyzed && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground bg-card border border-border rounded-md px-3 py-1.5">
            <Zap className="w-3.5 h-3.5 text-primary" />
            Parsed {logs.length.toLocaleString()} entries in {parseTime.toFixed(1)}ms
          </div>
        )}
      </div>

      <div className="cyber-card p-5 mb-4">
        <div className="flex items-center gap-3 mb-3 flex-wrap">
          <label className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md cursor-pointer hover:bg-primary/90 transition text-sm font-medium">
            <Upload className="w-4 h-4" />
            Upload Log File
            <input
              ref={fileInputRef}
              type="file"
              accept=".txt,.log,.csv,.json"
              className="hidden"
              onChange={handleFileUpload}
            />
          </label>
          {(rawLog || analyzed) && (
            <button
              onClick={clearAll}
              className="px-4 py-2 text-sm text-muted-foreground hover:text-destructive border border-border rounded-md hover:bg-destructive/10 transition ml-auto"
            >
              Clear
            </button>
          )}
          {fileName && (
            <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-mono">
              <FileText className="w-3.5 h-3.5" />
              {fileName}
            </span>
          )}
        </div>
        <textarea
          value={rawLog}
          onChange={e => setRawLog(e.target.value)}
          placeholder="Paste real log entries here, or upload a file above..."
          className="w-full h-32 bg-background border border-border rounded-md p-3 text-xs font-mono text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-primary"
        />
        <div className="flex items-center gap-3 mt-3">
          <button
            onClick={handleAnalyze}
            disabled={!rawLog.trim() || isPending}
            className="px-6 py-2.5 bg-primary text-primary-foreground rounded-md font-medium text-sm hover:bg-primary/90 disabled:opacity-40 transition flex items-center gap-2"
          >
            {isPending ? (
              <>
                <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                Analyze Logs
              </>
            )}
          </button>
          {rawLog && !isPending && (
            <span className="text-xs text-muted-foreground">
              {rawLog.split('\n').filter(l => l.trim()).length.toLocaleString()} lines ready
            </span>
          )}
        </div>
      </div>

      {analyzed && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <div className="cyber-card p-4">
              <p className="text-xs text-muted-foreground mb-1">Total Entries</p>
              <p className="text-2xl font-bold font-mono text-foreground">{logs.length.toLocaleString()}</p>
            </div>
            <div className="cyber-card p-4">
              <p className="text-xs text-muted-foreground mb-1">Failed Events</p>
              <p className="text-2xl font-bold font-mono text-destructive">{stats.failed.toLocaleString()}</p>
            </div>
            <div className="cyber-card p-4">
              <p className="text-xs text-muted-foreground mb-1">Warnings</p>
              <p className="text-2xl font-bold font-mono text-warning">{stats.warning.toLocaleString()}</p>
            </div>
            <div className="cyber-card p-4">
              <p className="text-xs text-muted-foreground mb-1">Suspicious IPs</p>
              <p className="text-2xl font-bold font-mono text-destructive">{stats.suspicious}</p>
            </div>
          </div>

          <div className="cyber-card p-5 mb-4">
            <h3 className="text-sm font-semibold text-foreground mb-3">
              IP Address Analysis ({ipAnalysis.length} unique IPs)
            </h3>
            <div className="overflow-auto max-h-80">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-card">
                  <tr className="border-b border-border text-muted-foreground text-left">
                    <th className="pb-2 pr-4">IP Address</th>
                    <th className="pb-2 pr-4">Total</th>
                    <th className="pb-2 pr-4">Failed</th>
                    <th className="pb-2 pr-4">Success</th>
                    <th className="pb-2 pr-4">Risk Level</th>
                    <th className="pb-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {ipAnalysis.map(ip => (
                    <tr key={ip.ip} className="border-b border-border/50 hover:bg-secondary/30 transition">
                      <td className="py-2 pr-4 font-mono text-foreground">{ip.ip}</td>
                      <td className="py-2 pr-4 font-mono">{ip.count}</td>
                      <td className="py-2 pr-4 font-mono text-destructive">{ip.failedAttempts}</td>
                      <td className="py-2 pr-4 font-mono text-primary">{ip.successAttempts}</td>
                      <td className={`py-2 pr-4 font-semibold ${riskColor(ip.riskLevel)}`}>{ip.riskLevel}</td>
                      <td className="py-2">
                        {ip.isSuspicious ? (
                          <span className="text-xs px-2 py-0.5 bg-destructive/15 text-destructive rounded-full">Suspicious</span>
                        ) : (
                          <span className="text-xs px-2 py-0.5 bg-primary/15 text-primary rounded-full">Normal</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="cyber-card p-5">
            <div className="flex items-center justify-between mb-3 gap-3 flex-wrap">
              <h3 className="text-sm font-semibold text-foreground">
                Parsed Log Entries
                <span className="text-muted-foreground font-normal ml-2">
                  ({filteredLogs.length.toLocaleString()}
                  {filteredLogs.length > VISIBLE_ROWS && ` — showing first ${VISIBLE_ROWS}`})
                </span>
              </h3>
              <div className="flex items-center gap-1.5 text-xs">
                <Filter className="w-3.5 h-3.5 text-muted-foreground" />
                {(['all', 'failed', 'warning', 'success'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setStatusFilter(f)}
                    className={`px-2.5 py-1 rounded-md font-medium capitalize transition ${
                      statusFilter === f
                        ? 'bg-primary/15 text-primary'
                        : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>
            <div className="max-h-80 overflow-auto space-y-0.5">
              {visibleLogs.map((entry, i) => (
                <div key={i} className="flex items-start gap-2 text-xs font-mono py-1 border-b border-border/30">
                  {statusIcon(entry.status)}
                  <span className="text-muted-foreground min-w-[140px]">{entry.timestamp}</span>
                  <span className="text-foreground min-w-[120px]">{entry.ip}</span>
                  <span className="text-muted-foreground truncate">{entry.details.slice(0, 120)}</span>
                </div>
              ))}
              {visibleLogs.length === 0 && (
                <p className="text-center text-muted-foreground text-sm py-8">No entries match this filter</p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
