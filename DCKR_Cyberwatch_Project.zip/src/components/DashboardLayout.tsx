import { useState } from 'react';
import { Shield, FileText, Network, Radio, AlertTriangle, Download, Activity, Globe, Menu, X, LogOut, Radar } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

interface DashboardLayoutProps {
  activeModule: string;
  onModuleChange: (module: string) => void;
  children: React.ReactNode;
}

const modules = [
  { id: 'overview', label: 'Overview', icon: Activity },
  { id: 'logs', label: 'Log Analyzer', icon: FileText },
  { id: 'scanner', label: 'Network Scanner', icon: Network },
  { id: 'packets', label: 'Packet Analyzer', icon: Radio },
  { id: 'ids', label: 'IDS & Alerts', icon: Radar },
  { id: 'threats', label: 'Threat Intel', icon: AlertTriangle },
  { id: 'scraper', label: 'Web Scraper', icon: Globe },
  { id: 'reports', label: 'Reports', icon: Download },
];

export default function DashboardLayout({ activeModule, onModuleChange, children }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, role, isAdmin, signOut } = useAuth();

  const handleModuleChange = (id: string) => {
    onModuleChange(id);
    setSidebarOpen(false);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-40 md:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed md:relative z-50 md:z-auto w-64 flex-shrink-0 border-r border-border bg-sidebar flex flex-col h-full transition-transform duration-200 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
      }`}>
        <div className="p-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10 pulse-glow">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-foreground cyber-glow-text">DC Krishna Reddy Cyberwatch</h1>
              <p className="text-[10px] text-muted-foreground tracking-wider uppercase">Intelligence System v2.0</p>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="md:hidden text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 p-3 space-y-0.5 overflow-auto">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider px-3 mb-2 mt-1">Modules</p>
          {modules.map(m => {
            const Icon = m.icon;
            const isActive = activeModule === m.id;
            return (
              <button
                key={m.id}
                onClick={() => handleModuleChange(m.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-primary/15 text-primary cyber-glow-text'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                <Icon className="w-4 h-4" />
                {m.label}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-border space-y-2">
          <div className="px-2 py-2 rounded-md bg-secondary/40">
            <div className="flex items-center justify-between mb-1 gap-2">
              <span className="text-foreground font-medium truncate text-xs">{user?.email ?? 'Guest'}</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono shrink-0 ${isAdmin ? 'bg-primary/20 text-primary' : 'bg-secondary text-muted-foreground'}`}>
                {(role ?? 'viewer').toUpperCase()}
              </span>
            </div>
            <button
              onClick={signOut}
              className="w-full mt-1 flex items-center gap-2 px-2 py-1 rounded text-muted-foreground hover:text-foreground hover:bg-secondary text-[11px]"
            >
              <LogOut className="w-3 h-3" /> Sign out
            </button>
          </div>
          <div className="flex items-center gap-2 px-1">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-xs text-muted-foreground">System Active</span>
          </div>
          <p className="text-[10px] text-muted-foreground/60 px-1">© 2026 DC Krishna Reddy Cyberwatch</p>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar for mobile */}
        <header className="md:hidden flex items-center gap-3 p-3 border-b border-border bg-card">
          <button onClick={() => setSidebarOpen(true)} className="text-muted-foreground hover:text-foreground">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-sm font-bold text-foreground">DC Krishna Reddy Cyberwatch</span>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
