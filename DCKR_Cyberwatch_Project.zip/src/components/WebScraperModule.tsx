import { useState, useCallback } from 'react';
import { Globe, Search, Link2, Image as ImageIcon, FileText, FormInput, AlertCircle, CheckCircle, Loader2, Download, ExternalLink, Mail, ShieldAlert } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

export interface ScrapeResult {
  url: string;
  title: string;
  description: string;
  headings: { level: string; text: string }[];
  paragraphs: string[];
  links: { href: string; text: string }[];
  images: { src: string; alt: string }[];
  forms: { action: string; method: string; inputs: string[] }[];
  emails: string[];
  findings: string[];
  scrapedAt: string;
  source: 'live' | 'simulated';
  httpStatus?: number;
  elapsedMs?: number;
  bytes?: number;
}

export default function WebScraperModule() {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<ScrapeResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [warning, setWarning] = useState('');
  const [activeTab, setActiveTab] = useState<'overview' | 'headings' | 'paragraphs' | 'links' | 'images' | 'forms'>('overview');

  const isValidUrl = (u: string) => {
    try {
      const parsed = new URL(u);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  };

  const normalizeUrl = (u: string) => {
    const trimmed = u.trim();
    if (!/^https?:\/\//i.test(trimmed)) return `https://${trimmed}`;
    return trimmed;
  };

  const handleScrape = useCallback(async () => {
    setError('');
    setWarning('');
    setResult(null);

    const target = normalizeUrl(url);
    if (!target) {
      setError('Please enter a URL');
      return;
    }
    if (!isValidUrl(target)) {
      setError('Invalid URL — must start with http:// or https://');
      return;
    }

    setLoading(true);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('web-scraper', {
        body: { url: target },
      });

      if (fnError) throw new Error(fnError.message || 'Edge function error');
      if (!data || data.error) throw new Error(data?.error || 'No data returned');

      const scraped = data as ScrapeResult;
      setResult(scraped);
      setActiveTab('overview');
      if (scraped.headings.length + scraped.paragraphs.length + scraped.links.length === 0) {
        setWarning('Page loaded but contains no extractable content (may be a JS-rendered SPA).');
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      setError(`Failed to scrape: ${msg}`);
    } finally {
      setLoading(false);
    }
  }, [url]);

  const handleDownload = () => {
    if (!result) return;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `scrape-${new URL(result.url).hostname}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const tabs = [
    { id: 'overview' as const, label: 'Overview', icon: FileText, count: result ? 1 : 0 },
    { id: 'headings' as const, label: 'Headings', icon: FileText, count: result?.headings.length || 0 },
    { id: 'paragraphs' as const, label: 'Paragraphs', icon: FileText, count: result?.paragraphs.length || 0 },
    { id: 'links' as const, label: 'Links', icon: Link2, count: result?.links.length || 0 },
    { id: 'images' as const, label: 'Images', icon: ImageIcon, count: result?.images.length || 0 },
    { id: 'forms' as const, label: 'Forms', icon: FormInput, count: result?.forms.length || 0 },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold text-foreground mb-1 cyber-glow-text">Web Scraper</h2>
      <p className="text-muted-foreground text-sm mb-6">Fetch and extract structured site content with better fallbacks and findings</p>

      <div className="cyber-card p-5 mb-4">
        <label className="text-xs text-muted-foreground mb-1.5 block">Target URL</label>
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              value={url}
              onChange={e => setUrl(e.target.value)}
              placeholder="https://example.com"
              onKeyDown={e => e.key === 'Enter' && !loading && handleScrape()}
              disabled={loading}
              className="w-full bg-background border border-border rounded-md pl-9 pr-3 py-2.5 text-sm font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary disabled:opacity-50"
            />
          </div>
          <button
            onClick={handleScrape}
            disabled={loading}
            className="px-6 py-2.5 bg-primary text-primary-foreground rounded-md font-medium text-sm hover:bg-primary/90 disabled:opacity-40 transition flex items-center gap-2"
          >
            {loading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Scraping...</>
            ) : (
              <><Search className="w-4 h-4" /> Scrape</>
            )}
          </button>
        </div>

        <div className="flex flex-wrap gap-2 mt-3">
          {['https://example.com', 'https://news.ycombinator.com', 'https://en.wikipedia.org/wiki/Cybersecurity'].map(example => (
            <button
              key={example}
              onClick={() => setUrl(example)}
              disabled={loading}
              className="text-xs px-2.5 py-1 border border-border rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary transition disabled:opacity-40"
            >
              {new URL(example).hostname}
            </button>
          ))}
        </div>

        {error && (
          <div className="mt-3 flex items-start gap-2 text-warning text-sm bg-warning/10 border border-warning/30 rounded-md p-2.5">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}
        {warning && !error && (
          <div className="mt-3 flex items-start gap-2 text-warning text-sm">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            {warning}
          </div>
        )}
      </div>

      {result && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
            {[
              { label: 'Headings', value: result.headings.length },
              { label: 'Paragraphs', value: result.paragraphs.length },
              { label: 'Links', value: result.links.length },
              { label: 'Images', value: result.images.length },
              { label: 'Forms', value: result.forms.length },
            ].map(stat => (
              <div key={stat.label} className="cyber-card p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">{stat.label}</p>
                <p className="text-xl font-bold font-mono text-primary">{stat.value}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-1.5 mb-4">
            {tabs.map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1.5 ${
                    activeTab === tab.id ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                  }`}
                >
                  <Icon className="w-3 h-3" />
                  {tab.label} ({tab.count})
                </button>
              );
            })}
          </div>

          <div className="cyber-card p-5">
            <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-primary" />
                {activeTab === 'overview' ? 'Page Overview' : activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
                {result.source === 'simulated' && (
                  <span className="text-xs px-2 py-0.5 bg-warning/15 text-warning rounded-full ml-1">demo data</span>
                )}
              </h3>
              <button
                onClick={handleDownload}
                className="px-3 py-1.5 text-xs border border-border rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary transition flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Download JSON
              </button>
            </div>

            <div className="max-h-96 overflow-auto">
              {activeTab === 'overview' && (
                <div className="space-y-3">
                  <div className="p-4 bg-background border border-border rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Page Title</p>
                    <p className="text-foreground font-semibold">{result.title}</p>
                  </div>
                  {result.description && (
                    <div className="p-4 bg-background border border-border rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Meta Description</p>
                      <p className="text-foreground text-sm">{result.description}</p>
                    </div>
                  )}
                  <div className="p-4 bg-background border border-border rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">URL</p>
                    <a href={result.url} target="_blank" rel="noreferrer" className="text-primary font-mono text-sm break-all hover:underline inline-flex items-center gap-1">
                      {result.url} <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <div className="p-4 bg-background border border-border rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Scraped At</p>
                    <p className="text-foreground font-mono text-sm">{new Date(result.scrapedAt).toLocaleString()}</p>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-4 bg-background border border-border rounded-lg">
                      <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" /> Emails</p>
                      {result.emails.length > 0 ? (
                        <div className="space-y-1">
                          {result.emails.map(email => <p key={email} className="text-sm font-mono text-foreground break-all">{email}</p>)}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground">No email addresses extracted</p>
                      )}
                    </div>
                    <div className="p-4 bg-background border border-border rounded-lg">
                      <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5"><ShieldAlert className="w-3.5 h-3.5" /> Findings</p>
                      {result.findings.length > 0 ? (
                        <div className="space-y-2">
                          {result.findings.map(finding => (
                            <div key={finding} className="text-sm text-foreground flex items-start gap-2">
                              <AlertCircle className="w-4 h-4 text-warning mt-0.5 shrink-0" />
                              <span>{finding}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-sm text-primary flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 mt-0.5 shrink-0" />
                          No obvious scraping hygiene issues detected
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'headings' && (
                <div className="space-y-1">
                  {result.headings.length === 0 && <p className="text-sm text-muted-foreground">No headings found</p>}
                  {result.headings.map((heading, index) => (
                    <div key={index} className="flex items-start gap-3 py-1.5 border-b border-border/30">
                      <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded shrink-0 ${
                        heading.level === 'H1' ? 'bg-primary/15 text-primary' :
                        heading.level === 'H2' ? 'bg-warning/15 text-warning' :
                        'bg-secondary text-muted-foreground'
                      }`}>{heading.level}</span>
                      <span className="text-sm text-foreground">{heading.text}</span>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'paragraphs' && (
                <div className="space-y-2">
                  {result.paragraphs.length === 0 && <p className="text-sm text-muted-foreground">No paragraphs found</p>}
                  {result.paragraphs.map((paragraph, index) => (
                    <div key={index} className="p-3 bg-background border border-border/50 rounded-lg text-sm text-foreground/80">
                      <span className="text-xs text-muted-foreground font-mono mr-2">P{index + 1}</span>
                      {paragraph}
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'links' && (
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-card">
                    <tr className="border-b border-border text-muted-foreground text-left">
                      <th className="pb-2 pr-4">#</th>
                      <th className="pb-2 pr-4">Text</th>
                      <th className="pb-2">URL</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.links.map((link, index) => (
                      <tr key={index} className="border-b border-border/30 hover:bg-secondary/30">
                        <td className="py-1.5 pr-4 text-muted-foreground font-mono text-xs">{index + 1}</td>
                        <td className="py-1.5 pr-4 text-foreground">{link.text}</td>
                        <td className="py-1.5">
                          <a href={link.href} target="_blank" rel="noreferrer" className="font-mono text-xs text-primary break-all hover:underline">
                            {link.href}
                          </a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {activeTab === 'images' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {result.images.map((image, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-background border border-border/50 rounded-lg">
                      <img
                        src={image.src}
                        alt={image.alt}
                        loading="lazy"
                        className="w-12 h-12 object-cover rounded bg-secondary shrink-0"
                        onError={e => { (e.currentTarget as HTMLImageElement).style.visibility = 'hidden'; }}
                      />
                      <div className="min-w-0">
                        <p className="text-sm text-foreground truncate">{image.alt || 'No alt text'}</p>
                        <a href={image.src} target="_blank" rel="noreferrer" className="text-xs text-primary font-mono truncate block hover:underline">{image.src}</a>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'forms' && (
                <div className="space-y-3">
                  {result.forms.length === 0 && <p className="text-sm text-muted-foreground">No forms found</p>}
                  {result.forms.map((form, index) => (
                    <div key={index} className="p-4 bg-background border border-border/50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <FormInput className="w-4 h-4 text-primary" />
                        <span className="text-sm font-semibold text-foreground">Form #{index + 1}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-warning/15 text-warning font-mono">{form.method}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-2 break-all">Action: <span className="text-primary font-mono">{form.action}</span></p>
                      <div className="flex flex-wrap gap-1.5">
                        {form.inputs.map((input, inputIndex) => (
                          <span key={inputIndex} className="text-xs px-2 py-0.5 bg-secondary text-secondary-foreground rounded-md font-mono">{input}</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
