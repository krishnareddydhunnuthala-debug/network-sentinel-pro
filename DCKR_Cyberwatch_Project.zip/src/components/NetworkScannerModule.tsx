import { useState, useCallback, useEffect, useRef } from 'react';
import { Play, Server, AlertCircle, Loader2, Square, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

import type { PortResult } from '@/lib/cyberUtils';

interface NetworkScannerProps {
  onScan: (target: string, results: PortResult[]) => void;
}

interface ScanSummary {
  host: string;
  startPort: number;
  endPort: number;
  total: number;
  open: number;
  closed: number;
  filtered: number;
  elapsedMs: number;
  scannedAt: string;
}

interface ScanBatchResponse {
  summary: ScanSummary;
  results: PortResult[];
}

const COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 587, 993, 995, 1433, 1521, 2049, 2375, 3000, 3306, 3389, 5000, 5432, 5900, 5984, 6379, 8000, 8080, 8443, 8888, 9000, 9200, 11211, 27017];
const CHUNK_SIZE = 400;
const PARALLEL_BATCHES = 4;
const PROBE_CONCURRENCY = 500;
const PROBE_TIMEOUT_MS = 350;
const RETRY_TIMEOUT_MS = 1200;

function normalizeScanHost(raw: string) {
  let host = raw.trim();
  host = host.replace(/^[a-z]+:\/\//i, '');
  host = host.split('/')[0].split('?')[0].split('#')[0];
  host = host.split('@').pop() || host;

  if (host.startsWith('[')) {
    const end = host.indexOf(']');
    if (end !== -1) host = host.slice(1, end);
  } else {
    host = host.split(':')[0];
  }

  return host.toLowerCase();
}

function getHostValidationError(raw: string) {
  const host = normalizeScanHost(raw);
  if (!host) return 'Enter a public hostname or IP address';
  if (/^(localhost|0\.0\.0\.0|::1)$/i.test(host) || /^127\./.test(host)) {
    return 'Localhost and loopback targets are blocked. Use a public host instead.';
  }
  if (/^10\./.test(host) || /^192\.168\./.test(host) || /^169\.254\./.test(host) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) {
    return 'Private network IPs are blocked. Use a public host instead.';
  }
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) return null;
  if (!/^[a-z0-9.-]+$/i.test(host) || !host.includes('.')) {
    return 'Enter a valid public hostname or IP address';
  }
  return null;
}

function buildRangePorts(start: number, end: number) {
  return Array.from({ length: end - start + 1 }, (_, index) => start + index);
}

export default function NetworkScannerModule({ onScan }: NetworkScannerProps) {
  const [targetHost, setTargetHost] = useState('scanme.nmap.org');
  const [startPort, setStartPort] = useState(1);
  const [endPort, setEndPort] = useState(1024);
  const [results, setResults] = useState<PortResult[]>([]);
  const [summary, setSummary] = useState<ScanSummary | null>(null);
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [error, setError] = useState('');
  const [mode, setMode] = useState<'range' | 'common'>('common');
  const cancelRef = useRef(false);
  const scanRunIdRef = useRef(0);

  const runBatch = useCallback(async (host: string, ports: number[], timeoutMs = PROBE_TIMEOUT_MS) => {
    const { data, error: fnError } = await supabase.functions.invoke('port-scanner', {
      body: {
        host,
        ports,
        concurrency: PROBE_CONCURRENCY,
        timeoutMs,
      },
    });

    if (fnError) throw new Error(fnError.message || 'Edge function error');
    if (!data || data.error) throw new Error(data?.error || 'Scan failed');
    return data as ScanBatchResponse;
  }, []);

  const clearScanState = useCallback((notifyParent = true) => {
    cancelRef.current = true;
    scanRunIdRef.current += 1;
    setScanning(false);
    setResults([]);
    setSummary(null);
    setError('');
    setProgress({ done: 0, total: 0 });

    if (notifyParent) {
      onScan('', []);
    }
  }, [onScan]);

  const handleScan = useCallback(async () => {
    const host = targetHost.trim();
    if (!host) {
      setError('Scan failed: target host is required');
      return;
    }

    const validationError = getHostValidationError(host);
    if (validationError) {
      setError(`Scan failed: ${validationError}`);
      return;
    }

    try {
      let portsToScan: number[];

      if (mode === 'common') {
        // Common mode probes only the curated service list so results come back much faster.
        portsToScan = [...COMMON_PORTS];
      } else {
        if (!Number.isInteger(startPort) || !Number.isInteger(endPort)) throw new Error('Ports must be whole numbers');
        if (startPort < 1 || endPort > 65535) throw new Error('Ports must be between 1 and 65535');
        if (endPort < startPort) throw new Error('End port must be ≥ start port');
        if (endPort - startPort + 1 > 10000) throw new Error('Maximum 10,000 ports per scan run');
        portsToScan = buildRangePorts(startPort, endPort);
      }

      const currentRunId = scanRunIdRef.current + 1;
      scanRunIdRef.current = currentRunId;
      cancelRef.current = false;
      setError('');
      setScanning(true);
      setResults([]);
      setSummary(null);
      setProgress({ done: 0, total: portsToScan.length });

      const chunks: number[][] = [];
      for (let index = 0; index < portsToScan.length; index += CHUNK_SIZE) {
        // Small batches keep the UI live and make cancel/clear responsive.
        chunks.push(portsToScan.slice(index, index + CHUNK_SIZE));
      }

      const startedAt = Date.now();
      const aggregated: PortResult[] = [];
      let openCount = 0;
      let closedCount = 0;
      let filteredCount = 0;

      let chunkIndex = 0;
      const runWorker = async () => {
        while (chunkIndex < chunks.length) {
          if (cancelRef.current || scanRunIdRef.current !== currentRunId) return;
          const myIndex = chunkIndex++;
          const chunk = chunks[myIndex];
          const { results: batchResults, summary: batchSummary } = await runBatch(host, chunk);
          if (cancelRef.current || scanRunIdRef.current !== currentRunId) return;
          aggregated.push(...batchResults);
          openCount += batchSummary.open;
          closedCount += batchSummary.closed;
          filteredCount += batchSummary.filtered;
          setProgress({ done: aggregated.length, total: portsToScan.length });
          setResults([...aggregated].sort((a, b) => a.port - b.port));
        }
      };
      await Promise.all(
        Array.from({ length: Math.min(PARALLEL_BATCHES, chunks.length) }, () => runWorker())
      );

      if (cancelRef.current || scanRunIdRef.current !== currentRunId) {
        throw new Error('Scan cancelled');
      }

      // Accuracy pass: re-probe filtered ports with a longer timeout to reduce false negatives.
      const filteredPortsToRetry = aggregated.filter(r => r.status === 'filtered').map(r => r.port);
      if (filteredPortsToRetry.length > 0 && filteredPortsToRetry.length <= 1000) {
        const retryChunks: number[][] = [];
        for (let i = 0; i < filteredPortsToRetry.length; i += CHUNK_SIZE) {
          retryChunks.push(filteredPortsToRetry.slice(i, i + CHUNK_SIZE));
        }
        const retryResultsMap = new Map<number, PortResult>();
        await Promise.all(retryChunks.map(async chunk => {
          if (cancelRef.current || scanRunIdRef.current !== currentRunId) return;
          const { results: retryResults } = await runBatch(host, chunk, RETRY_TIMEOUT_MS);
          retryResults.forEach(r => retryResultsMap.set(r.port, r));
        }));
        if (cancelRef.current || scanRunIdRef.current !== currentRunId) throw new Error('Scan cancelled');
        for (let i = 0; i < aggregated.length; i++) {
          const retried = retryResultsMap.get(aggregated[i].port);
          if (retried && aggregated[i].status === 'filtered' && retried.status !== 'filtered') {
            aggregated[i] = retried;
          }
        }
        openCount = aggregated.filter(r => r.status === 'open').length;
        closedCount = aggregated.filter(r => r.status === 'closed').length;
        filteredCount = aggregated.filter(r => r.status === 'filtered').length;
        setResults([...aggregated].sort((a, b) => a.port - b.port));
      }

      const finalResults = [...aggregated].sort((a, b) => a.port - b.port);
      const finalSummary: ScanSummary = {
        host,
        startPort: Math.min(...portsToScan),
        endPort: Math.max(...portsToScan),
        total: finalResults.length,
        open: openCount,
        closed: closedCount,
        filtered: filteredCount,
        elapsedMs: Date.now() - startedAt,
        scannedAt: new Date().toISOString(),
      };

      if (cancelRef.current || scanRunIdRef.current !== currentRunId) {
        return;
      }

      setResults(finalResults);
      setSummary(finalSummary);
      onScan(host, finalResults);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      if (msg !== 'Scan cancelled') {
        setError(`Scan failed: ${msg}`);
      }
    } finally {
      setScanning(false);
    }
  }, [targetHost, startPort, endPort, mode, onScan, runBatch]);

  const cancelScan = useCallback(() => {
    cancelRef.current = true;
    scanRunIdRef.current += 1;
    setScanning(false);
  }, []);

  useEffect(() => () => {
    cancelRef.current = true;
    scanRunIdRef.current += 1;
  }, []);

  const statusColor = (status: string) => {
    if (status === 'open') return 'text-primary';
    if (status === 'filtered') return 'text-warning';
    return 'text-muted-foreground';
  };

  const visible = results.filter(result => result.status !== 'closed');
  const openPorts = results.filter(result => result.status === 'open');
  const filteredPorts = results.filter(result => result.status === 'filtered');
  const progressPct = progress.total ? Math.min(100, Math.round((progress.done / progress.total) * 100)) : 0;
  const canClear = results.length > 0 || summary !== null || progress.done > 0 || !!error;
  const hostValidationError = getHostValidationError(targetHost);

  return (
    <div>
      <h2 className="text-2xl font-bold text-foreground mb-1 cyber-glow-text">Network Scanner</h2>
      <p className="text-muted-foreground text-sm mb-6">Real TCP connect-probe scan with live progress, fast common-port mode, and clean reset behavior.</p>

      <div className="cyber-card p-5 mb-4">
        <div className="flex gap-2 mb-3">
          <button
            onClick={() => setMode('common')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition ${mode === 'common' ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}
          >Common Services</button>
          <button
            onClick={() => setMode('range')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition ${mode === 'range' ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}
          >Custom Range (up to 10,000)</button>
        </div>

        <div className={`grid grid-cols-1 ${mode === 'range' ? 'md:grid-cols-4' : 'md:grid-cols-2'} gap-3 mb-3`}>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Target Host or IP</label>
            <input
              value={targetHost}
              onChange={event => setTargetHost(event.target.value)}
              placeholder="e.g. scanme.nmap.org"
              className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
            {hostValidationError && <p className="mt-1 text-xs text-warning">{hostValidationError}</p>}
          </div>
          {mode === 'range' && (
            <>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Start Port</label>
                <input
                  type="number"
                  value={startPort}
                  onChange={event => setStartPort(Number(event.target.value))}
                  min={1}
                  max={65535}
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">End Port</label>
                <input
                  type="number"
                  value={endPort}
                  onChange={event => setEndPort(Number(event.target.value))}
                  min={1}
                  max={65535}
                  className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
            </>
          )}
          <div className="flex items-end gap-2">
            {!scanning ? (
              <button
                onClick={handleScan}
                disabled={!targetHost.trim() || !!hostValidationError}
                className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-md font-medium text-sm hover:bg-primary/90 disabled:opacity-40 transition flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4" /> Start Scan
              </button>
            ) : (
              <button
                onClick={cancelScan}
                className="flex-1 px-4 py-2 bg-destructive text-destructive-foreground rounded-md font-medium text-sm hover:bg-destructive/90 transition flex items-center justify-center gap-2"
              >
                <Square className="w-4 h-4" /> Cancel
              </button>
            )}
            <button
              onClick={() => clearScanState(true)}
              disabled={!canClear}
              className="px-4 py-2 border border-border rounded-md text-sm text-muted-foreground hover:text-foreground hover:bg-secondary disabled:opacity-40 transition flex items-center justify-center gap-2"
            >
              <Trash2 className="w-4 h-4" /> Clear
            </button>
          </div>
        </div>

        {scanning && (
          <div className="mt-2">
            <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
              <span className="flex items-center gap-2"><Loader2 className="w-3 h-3 animate-spin" /> Scanning {progress.done.toLocaleString()} / {progress.total.toLocaleString()} ports</span>
              <span className="font-mono">{progressPct}%</span>
            </div>
            <div className="h-1.5 w-full bg-secondary rounded">
              <div className="h-1.5 bg-primary rounded transition-all" style={{ width: `${progressPct}%` }} />
            </div>
          </div>
        )}

        <p className="text-xs text-muted-foreground mt-2">
          Common mode probes {COMMON_PORTS.length} high-value ports only. Custom mode scans up to 10,000 ports in live 500-port batches with 500 concurrent probes.
        </p>

        {error && (
          <div className="mt-3 p-2.5 rounded-md border border-destructive/30 bg-destructive/10 text-destructive text-sm flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}
      </div>

      {summary && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Open Ports</p>
              <p className="text-2xl font-bold font-mono text-primary">{summary.open}</p>
            </div>
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Filtered</p>
              <p className="text-2xl font-bold font-mono text-warning">{filteredPorts.length}</p>
            </div>
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Closed</p>
              <p className="text-2xl font-bold font-mono text-muted-foreground">{summary.closed}</p>
            </div>
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Scanned</p>
              <p className="text-2xl font-bold font-mono text-foreground">{summary.total}</p>
            </div>
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Elapsed</p>
              <p className="text-2xl font-bold font-mono text-foreground">{(summary.elapsedMs / 1000).toFixed(1)}s</p>
            </div>
          </div>

          <div className="cyber-card p-5">
            <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
              <h3 className="text-sm font-semibold text-foreground">Scan Results — {summary.host}</h3>
              <span className="text-xs text-muted-foreground font-mono">{new Date(summary.scannedAt).toLocaleString()}</span>
            </div>
            <div className="overflow-auto max-h-96">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-card">
                  <tr className="border-b border-border text-muted-foreground text-left">
                    <th className="pb-2 pr-4">Port</th>
                    <th className="pb-2 pr-4">Status</th>
                    <th className="pb-2 pr-4">Service</th>
                    <th className="pb-2">Response</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.length === 0 && (
                    <tr><td colSpan={4} className="py-8 text-center text-muted-foreground">No open or filtered ports detected</td></tr>
                  )}
                  {visible.map(result => (
                    <tr key={result.port} className="border-b border-border/30">
                      <td className="py-2 pr-4 font-mono text-foreground">{result.port}</td>
                      <td className={`py-2 pr-4 font-semibold ${statusColor(result.status)}`}>
                        <span className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${result.status === 'open' ? 'bg-primary' : 'bg-warning'}`} />
                          {result.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-2 pr-4 text-muted-foreground">
                        <span className="flex items-center gap-2"><Server className="w-3.5 h-3.5" />{result.service}</span>
                      </td>
                      <td className="py-2 font-mono text-xs text-muted-foreground">{result.responseTimeMs ? `${result.responseTimeMs}ms` : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {openPorts.length > 0 && (
              <div className="mt-4 pt-4 border-t border-border/40 text-xs text-muted-foreground">
                <strong className="text-foreground">Detected services:</strong>{' '}
                {openPorts.map(port => `${port.port}/${port.service}`).join(', ')}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
