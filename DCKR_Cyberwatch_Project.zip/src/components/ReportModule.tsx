import { Download, FileJson, FileText, CheckCircle } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { generateReport, type LogEntry, type IPAnalysis, type PortResult, type PacketData, type ThreatEntry } from '@/lib/cyberUtils';

interface ReportModuleProps {
  logs: LogEntry[];
  ipAnalysis: IPAnalysis[];
  portScan: { target: string; results: PortResult[] } | null;
  packets: PacketData[];
  threats: ThreatEntry[];
}

export default function ReportModule({ logs, ipAnalysis, portScan, packets, threats }: ReportModuleProps) {
  const report = generateReport({ logs, ipAnalysis, portScan: portScan || undefined, packets, threats });

  const downloadFile = (content: string, type: string, filename: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  };

  const toCsvCell = (value: unknown) => `"${String(value ?? '').split('"').join('""')}"`;

  const buildSections = (): Array<{ title: string; head: string[]; rows: string[][] }> => [
    {
      title: 'Report Summary',
      head: ['Metric', 'Value'],
      rows: Object.entries(report.summary).map(([k, v]) => [k.replace(/([A-Z])/g, ' $1').trim(), String(v)]),
    },
    {
      title: 'Suspicious IPs',
      head: ['IP', 'Risk', 'Events', 'Failed', 'Successful'],
      rows: report.detailedFindings.suspiciousIPs.length > 0
        ? report.detailedFindings.suspiciousIPs.map(ip => [ip.ip, ip.riskLevel, String(ip.count), String(ip.failedAttempts), String(ip.successAttempts)])
        : [['—', '—', '—', '—', '—']],
    },
    {
      title: 'Open Services',
      head: ['Port', 'Status', 'Service'],
      rows: report.detailedFindings.openServices.length > 0
        ? report.detailedFindings.openServices.map(s => [String(s.port), s.status, s.service])
        : [['—', '—', '—']],
    },
    {
      title: 'Anomalous Packets',
      head: ['ID', 'Time', 'Destination', 'Port', 'Protocol', 'Severity', 'Finding'],
      rows: report.detailedFindings.anomalousPackets.length > 0
        ? report.detailedFindings.anomalousPackets.map(p => [
            String(p.id),
            new Date(p.timestamp).toLocaleString(),
            p.destination,
            String(p.destinationPort || ''),
            p.protocol,
            p.severity || 'info',
            p.anomaly || '',
          ])
        : [['—', '—', '—', '—', '—', '—', '—']],
    },
    {
      title: 'Threat Intelligence',
      head: ['IP', 'Risk', 'Category', 'Reports', 'Last Seen', 'Confidence', 'Source'],
      rows: threats.length > 0
        ? threats.map(t => [t.ip, t.riskLevel, t.category, String(t.reportCount ?? ''), t.lastSeen ?? '', String(t.confidence ?? ''), t.source ?? ''])
        : [['—', '—', '—', '—', '—', '—', '—']],
    },
  ];

  const handleJsonDownload = () => {
    downloadFile(JSON.stringify(report, null, 2), 'application/json', `cyberwatch-report-${Date.now()}.json`);
  };

  const handleCsvDownload = () => {
    const sections = buildSections();
    const csv = sections.flatMap(s => [
      [toCsvCell(s.title)],
      s.head.map(toCsvCell),
      ...s.rows.map(r => r.map(toCsvCell)),
      [''],
    ]).map(row => row.join(',')).join('\n');
    downloadFile(csv, 'text/csv;charset=utf-8', `cyberwatch-report-table-${Date.now()}.csv`);
  };

  const handleTextDownload = () => {
    const sections = buildSections();
    const lines: string[] = [
      '═══════════════════════════════════════════',
      '  YASH KL CYBERWATCH — INTELLIGENCE REPORT',
      '═══════════════════════════════════════════',
      `Report ID:    ${report.reportId}`,
      `Generated:    ${report.generatedAt}`,
      '',
    ];
    for (const s of sections) {
      lines.push(`── ${s.title} ──`);
      lines.push(s.head.join(' | '));
      lines.push('-'.repeat(60));
      s.rows.forEach(r => lines.push(r.join(' | ')));
      lines.push('');
    }
    downloadFile(lines.join('\n'), 'text/plain;charset=utf-8', `cyberwatch-report-${Date.now()}.txt`);
  };

  const handlePdfDownload = () => {
    const doc = new jsPDF({ unit: 'pt', format: 'a4' });
    const pageWidth = doc.internal.pageSize.getWidth();

    // Header
    doc.setFillColor(20, 30, 48);
    doc.rect(0, 0, pageWidth, 70, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18); doc.setFont('helvetica', 'bold');
    doc.text("DC Krishna Reddy Cyberwatch", 40, 32);
    doc.setFontSize(10); doc.setFont('helvetica', 'normal');
    doc.text('Intelligence Report', 40, 50);
    doc.setFontSize(8);
    doc.text(`Report ID: ${report.reportId}`, pageWidth - 40, 32, { align: 'right' });
    doc.text(`Generated: ${new Date(report.generatedAt).toLocaleString()}`, pageWidth - 40, 50, { align: 'right' });

    let cursorY = 90;
    doc.setTextColor(20, 30, 48);

    for (const section of buildSections()) {
      if (cursorY > 740) { doc.addPage(); cursorY = 50; }
      doc.setFontSize(12); doc.setFont('helvetica', 'bold');
      doc.text(section.title, 40, cursorY);
      cursorY += 8;
      autoTable(doc, {
        head: [section.head],
        body: section.rows,
        startY: cursorY,
        margin: { left: 40, right: 40 },
        theme: 'grid',
        styles: { fontSize: 8, cellPadding: 4, overflow: 'linebreak' },
        headStyles: { fillColor: [37, 99, 235], textColor: 255, fontStyle: 'bold' },
        alternateRowStyles: { fillColor: [245, 247, 250] },
      });
      // @ts-expect-error autoTable attaches lastAutoTable
      cursorY = (doc.lastAutoTable?.finalY ?? cursorY) + 24;
    }

    // Footer page numbers
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(8); doc.setTextColor(120, 120, 120);
      doc.text(`Page ${i} of ${totalPages}`, pageWidth / 2, doc.internal.pageSize.getHeight() - 20, { align: 'center' });
    }

    doc.save(`cyberwatch-report-${Date.now()}.pdf`);
  };

  const hasData = logs.length > 0 || (portScan?.results.length ?? 0) > 0 || packets.length > 0 || threats.length > 0;

  return (
    <div>
      <h2 className="text-2xl font-bold text-foreground mb-1 cyber-glow-text">Report Generation</h2>
      <p className="text-muted-foreground text-sm mb-6">Download structured analysis reports as PDF, JSON, CSV, or plain text</p>

      <div className="cyber-card p-5 mb-4">
        <h3 className="text-sm font-semibold text-foreground mb-4">Report Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {Object.entries(report.summary).map(([key, val]) => (
            <div key={key} className="text-center">
              <p className="text-2xl font-bold font-mono text-primary">{val}</p>
              <p className="text-xs text-muted-foreground mt-1">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-3 mb-4">
          {hasData ? (
            <div className="flex items-center gap-2 text-primary text-sm">
              <CheckCircle className="w-4 h-4" /> Data available for report generation
            </div>
          ) : (
            <div className="text-muted-foreground text-sm">Run analyses in other modules first to populate the report</div>
          )}
        </div>

        <div className="flex flex-wrap gap-3">
          <button onClick={handlePdfDownload}
            className="px-5 py-2.5 bg-primary text-primary-foreground rounded-md font-medium text-sm hover:bg-primary/90 transition flex items-center gap-2">
            <Download className="w-4 h-4" /> Download PDF
          </button>
          <button onClick={handleJsonDownload}
            className="px-5 py-2.5 border border-border text-foreground rounded-md font-medium text-sm hover:bg-secondary transition flex items-center gap-2">
            <FileJson className="w-4 h-4" /> JSON
          </button>
          <button onClick={handleCsvDownload}
            className="px-5 py-2.5 border border-border text-foreground rounded-md font-medium text-sm hover:bg-secondary transition flex items-center gap-2">
            <Download className="w-4 h-4" /> CSV Table
          </button>
          <button onClick={handleTextDownload}
            className="px-5 py-2.5 border border-border text-foreground rounded-md font-medium text-sm hover:bg-secondary transition flex items-center gap-2">
            <FileText className="w-4 h-4" /> Text
          </button>
        </div>
      </div>

      <div className="cyber-card p-5">
        <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
          <FileJson className="w-4 h-4 text-primary" /> Report Preview
        </h3>
        <pre className="bg-background border border-border rounded-md p-4 text-xs font-mono text-foreground overflow-auto max-h-96">
          {JSON.stringify(report, null, 2)}
        </pre>
      </div>
    </div>
  );
}
