import { useState, useCallback } from 'react';
import { AlertTriangle, Search, Shield, Info, Loader2, Globe, MapPin, Network } from 'lucide-react';
import { isValidIPv4, type ThreatEntry } from '@/lib/cyberUtils';
import { supabase } from '@/integrations/supabase/client';

interface ThreatIntelProps {
  onUpdate: (threats: ThreatEntry[]) => void;
}

export default function ThreatIntelModule({ onUpdate }: ThreatIntelProps) {
  const [searchIP, setSearchIP] = useState('');
  const [result, setResult] = useState<ThreatEntry | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearch = useCallback(async () => {
    const ip = searchIP.trim();
    setError('');
    setResult(null);

    if (!ip) {
      setError('Enter an IP address to analyze.');
      return;
    }
    if (!isValidIPv4(ip)) {
      setError('Enter a valid IPv4 address.');
      return;
    }

    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('ip-intel', { body: { ip } });
      if (fnError) throw new Error(fnError.message || 'Lookup failed');
      if (!data || data.error) throw new Error(data?.error || 'No data returned');

      const threat = data as ThreatEntry;
      setResult(threat);
      onUpdate([threat]);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      setError(`Lookup failed: ${msg}`);
    } finally {
      setLoading(false);
    }
  }, [searchIP, onUpdate]);

  const riskBadge = (level: string) => {
    const cls = level === 'High' ? 'bg-destructive/15 text-destructive' : level === 'Medium' ? 'bg-warning/15 text-warning' : 'bg-primary/15 text-primary';
    return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cls}`}>{level}</span>;
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-foreground mb-1 cyber-glow-text">Threat Intelligence</h2>
      <p className="text-muted-foreground text-sm mb-6">Real-time IP enrichment using live geolocation, ASN, and anonymizer signals</p>

      <div className="cyber-card p-5 mb-4">
        <label className="text-xs text-muted-foreground mb-1 block">IP Address</label>
        <div className="flex gap-2">
          <input
            value={searchIP}
            onChange={e => setSearchIP(e.target.value)}
            placeholder="e.g. 8.8.8.8"
            className="flex-1 bg-background border border-border rounded-md px-3 py-2 text-sm font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            onKeyDown={e => e.key === 'Enter' && !loading && handleSearch()}
            disabled={loading}
          />
          <button
            onClick={handleSearch}
            disabled={loading}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 disabled:opacity-40 transition flex items-center gap-2"
          >
            {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Looking up...</> : <><Search className="w-4 h-4" /> Lookup</>}
          </button>
        </div>

        {error && (
          <div className="mt-3 p-2.5 rounded-md border border-warning/30 bg-warning/10 text-warning text-sm flex items-center gap-2">
            <Info className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}
      </div>

      {result && (
        <div className="space-y-4">
          <div className={`cyber-card p-5 border ${
            result.riskLevel === 'High' ? 'border-destructive/40 bg-destructive/5' :
            result.riskLevel === 'Medium' ? 'border-warning/40 bg-warning/5' :
            'border-primary/40 bg-primary/5'
          }`}>
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              {result.riskLevel === 'High' ? <AlertTriangle className="w-5 h-5 text-destructive" /> : <Shield className="w-5 h-5 text-primary" />}
              <span className="font-mono text-foreground font-semibold text-lg">{result.ip}</span>
              {riskBadge(result.riskLevel)}
              <span className="text-xs text-muted-foreground ml-auto">{result.confidence ?? 0}% confidence</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
              <div><span className="text-muted-foreground">Category:</span> <span className="text-foreground">{result.category}</span></div>
              <div><span className="text-muted-foreground">Source:</span> <span className="text-foreground">{result.source}</span></div>
            </div>
            <div className="mt-3 text-sm">
              <p className="text-muted-foreground mb-1">Recommended Action:</p>
              <p className="text-foreground">{result.recommendation}</p>
            </div>
            {!!result.indicators?.length && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {result.indicators.map(indicator => (
                  <span key={indicator} className="text-xs px-2 py-0.5 rounded-md bg-secondary text-secondary-foreground">{indicator}</span>
                ))}
              </div>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {result.geo && (result.geo.country || result.geo.city) && (
              <div className="cyber-card p-5">
                <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-primary" />
                  Geolocation
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Country</span><span className="text-foreground">{result.geo.country} {result.geo.countryCode && `(${result.geo.countryCode})`}</span></div>
                  {result.geo.region && <div className="flex justify-between"><span className="text-muted-foreground">Region</span><span className="text-foreground">{result.geo.region}</span></div>}
                  {result.geo.city && <div className="flex justify-between"><span className="text-muted-foreground">City</span><span className="text-foreground">{result.geo.city}</span></div>}
                  {result.geo.zip && <div className="flex justify-between"><span className="text-muted-foreground">Postal</span><span className="text-foreground font-mono">{result.geo.zip}</span></div>}
                  {result.geo.lat !== undefined && result.geo.lon !== undefined && (
                    <div className="flex justify-between"><span className="text-muted-foreground">Coords</span><span className="text-foreground font-mono">{result.geo.lat.toFixed(2)}, {result.geo.lon.toFixed(2)}</span></div>
                  )}
                  {result.geo.timezone && <div className="flex justify-between"><span className="text-muted-foreground">Timezone</span><span className="text-foreground">{result.geo.timezone}</span></div>}
                </div>
              </div>
            )}

            {result.network && (result.network.isp || result.network.asn) && (
              <div className="cyber-card p-5">
                <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                  <Network className="w-4 h-4 text-primary" />
                  Network Information
                </h3>
                <div className="space-y-2 text-sm">
                  {result.network.isp && <div className="flex justify-between gap-3"><span className="text-muted-foreground shrink-0">ISP</span><span className="text-foreground text-right">{result.network.isp}</span></div>}
                  {result.network.org && <div className="flex justify-between gap-3"><span className="text-muted-foreground shrink-0">Organization</span><span className="text-foreground text-right">{result.network.org}</span></div>}
                  {result.network.asn && <div className="flex justify-between gap-3"><span className="text-muted-foreground shrink-0">ASN</span><span className="text-foreground font-mono text-right">{result.network.asn}</span></div>}
                  {result.network.reverseDns && <div className="flex justify-between gap-3"><span className="text-muted-foreground shrink-0">Reverse DNS</span><span className="text-foreground font-mono text-xs text-right break-all">{result.network.reverseDns}</span></div>}
                </div>
              </div>
            )}
          </div>

          {result.flags && (
            <div className="cyber-card p-5">
              <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                <Globe className="w-4 h-4 text-primary" />
                Network Flags
              </h3>
              <div className="grid grid-cols-3 gap-3">
                {(['proxy', 'hosting', 'mobile'] as const).map(flag => (
                  <div key={flag} className={`p-3 rounded-lg border text-center ${result.flags?.[flag] ? 'border-warning/40 bg-warning/10' : 'border-border bg-background'}`}>
                    <p className="text-xs text-muted-foreground capitalize mb-1">{flag}</p>
                    <p className={`text-sm font-semibold font-mono ${result.flags?.[flag] ? 'text-warning' : 'text-muted-foreground'}`}>
                      {result.flags?.[flag] ? 'YES' : 'NO'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {!result && !error && !loading && (
        <div className="cyber-card p-12 text-center">
          <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-40" />
          <p className="text-muted-foreground text-sm">
            Enter any public IPv4 address to fetch live geolocation, ASN, and anonymizer flags
          </p>
        </div>
      )}
    </div>
  );
}
