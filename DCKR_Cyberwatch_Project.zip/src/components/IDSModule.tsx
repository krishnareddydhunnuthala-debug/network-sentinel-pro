import { useEffect, useMemo, useRef, useState } from 'react';
import { ShieldAlert, AlertTriangle, Activity, Bell, Trash2, Pause, Play, Radar } from 'lucide-react';
import { toast } from 'sonner';
import { type LogEntry, type IPAnalysis, type PacketData } from '@/lib/cyberUtils';

interface Alert {
  id: string;
  ts: number;
  severity: 'low' | 'medium' | 'high';
  source: string;
  category: string;
  message: string;
}

interface IDSProps {
  logs: LogEntry[];
  ipAnalysis: IPAnalysis[];
  packets: PacketData[];
}

const sevColor = {
  low: 'text-success border-success/40 bg-success/5',
  medium: 'text-warning border-warning/40 bg-warning/5',
  high: 'text-destructive border-destructive/50 bg-destructive/10',
};

export default function IDSModule({ logs, ipAnalysis, packets }: IDSProps) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [paused, setPaused] = useState(false);
  const [filter, setFilter] = useState<'all' | 'low' | 'medium' | 'high'>('all');
  const seenRef = useRef<Set<string>>(new Set());

  // Build alerts from packets + ip analysis (live)
  useEffect(() => {
    if (paused) return;
    const next: Alert[] = [];

    packets.forEach(p => {
      if (!p.anomaly) return;
      const key = `pkt-${p.id}-${p.anomaly}`;
      if (seenRef.current.has(key)) return;
      seenRef.current.add(key);
      const sev = (p.severity ?? 'medium') as 'low' | 'medium' | 'high';
      next.push({
        id: key,
        ts: Date.now(),
        severity: sev,
        source: p.source || p.destination || 'unknown',
        category: p.category || 'Packet Anomaly',
        message: `${p.anomaly} — ${p.protocol} ${p.destination}${p.destinationPort ? ':' + p.destinationPort : ''}`,
      });
    });

    ipAnalysis.forEach(ip => {
      if (ip.riskLevel === 'Low') return;
      const key = `ip-${ip.ip}-${ip.riskLevel}`;
      if (seenRef.current.has(key)) return;
      seenRef.current.add(key);
      next.push({
        id: key,
        ts: Date.now(),
        severity: ip.riskLevel === 'High' ? 'high' : 'medium',
        source: ip.ip,
        category: 'Suspicious IP',
        message: `${ip.ip} flagged ${ip.riskLevel} (${ip.failedAttempts}/${ip.count} failed requests)`,
      });
    });

    if (next.length) {
      setAlerts(prev => [...next, ...prev].slice(0, 500));
      const high = next.find(a => a.severity === 'high');
      if (high) toast.error(`IDS: ${high.message}`, { description: high.source });
      else if (next[0]) toast.warning(`IDS: ${next[0].message}`);
    }
  }, [packets, ipAnalysis, paused]);

  const filtered = useMemo(
    () => alerts.filter(a => filter === 'all' || a.severity === filter),
    [alerts, filter]
  );

  const counts = useMemo(() => ({
    high: alerts.filter(a => a.severity === 'high').length,
    medium: alerts.filter(a => a.severity === 'medium').length,
    low: alerts.filter(a => a.severity === 'low').length,
  }), [alerts]);

  // Time-bucket histogram for last 60s
  const histogram = useMemo(() => {
    const buckets = Array(30).fill(0);
    const now = Date.now();
    alerts.forEach(a => {
      const idx = Math.floor((now - a.ts) / 2000);
      if (idx >= 0 && idx < 30) buckets[29 - idx]++;
    });
    return buckets;
  }, [alerts]);

  const maxBar = Math.max(1, ...histogram);

  const clear = () => {
    setAlerts([]);
    seenRef.current.clear();
    toast.success('IDS alerts cleared');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-foreground cyber-glow-text flex items-center gap-2">
            <Radar className="w-6 h-6 text-primary" /> Intrusion Detection System
          </h2>
          <p className="text-muted-foreground text-sm">Live correlation of packets, log IPs and anomaly signatures</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPaused(p => !p)}
            className="px-3 py-1.5 rounded border border-primary/40 text-primary text-xs flex items-center gap-1.5 hover:bg-primary/10"
          >
            {paused ? <><Play className="w-3 h-3" /> Resume</> : <><Pause className="w-3 h-3" /> Pause</>}
          </button>
          <button
            onClick={clear}
            className="px-3 py-1.5 rounded border border-destructive/40 text-destructive text-xs flex items-center gap-1.5 hover:bg-destructive/10"
          >
            <Trash2 className="w-3 h-3" /> Clear
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Alerts', value: alerts.length, icon: Bell, color: 'text-primary' },
          { label: 'High', value: counts.high, icon: ShieldAlert, color: 'text-destructive' },
          { label: 'Medium', value: counts.medium, icon: AlertTriangle, color: 'text-warning' },
          { label: 'Low', value: counts.low, icon: Activity, color: 'text-success' },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="cyber-card p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{c.label}</span>
                <Icon className={`w-4 h-4 ${c.color}`} />
              </div>
              <p className={`text-2xl font-bold font-mono ${c.color}`}>{c.value}</p>
            </div>
          );
        })}
      </div>

      {/* Visualization */}
      <div className="cyber-card p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" /> Alert Frequency (last 60s)
          </h3>
          <span className="text-[10px] text-muted-foreground font-mono">{paused ? 'PAUSED' : 'LIVE'}</span>
        </div>
        <div className="flex items-end gap-1 h-32">
          {histogram.map((v, i) => (
            <div
              key={i}
              className="flex-1 bg-primary/70 rounded-t-sm transition-all"
              style={{
                height: `${(v / maxBar) * 100}%`,
                minHeight: v ? '4px' : '2px',
                opacity: v ? 0.4 + (v / maxBar) * 0.6 : 0.15,
                boxShadow: v ? '0 0 8px hsl(var(--primary) / 0.6)' : 'none',
              }}
              title={`${v} alerts`}
            />
          ))}
        </div>
        <div className="flex justify-between text-[10px] text-muted-foreground font-mono mt-2">
          <span>-60s</span><span>-30s</span><span>now</span>
        </div>
      </div>

      {/* Severity breakdown bar */}
      <div className="cyber-card p-5">
        <h3 className="text-sm font-semibold text-foreground mb-3">Severity Distribution</h3>
        {alerts.length === 0 ? (
          <p className="text-xs text-muted-foreground">No alerts yet. Run a packet capture or analyze logs to feed the IDS.</p>
        ) : (
          <div className="flex h-3 rounded overflow-hidden border border-border">
            <div className="bg-destructive" style={{ width: `${(counts.high / alerts.length) * 100}%` }} />
            <div className="bg-warning" style={{ width: `${(counts.medium / alerts.length) * 100}%` }} />
            <div className="bg-success" style={{ width: `${(counts.low / alerts.length) * 100}%` }} />
          </div>
        )}
      </div>

      {/* Alerts list */}
      <div className="cyber-card p-5">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Bell className="w-4 h-4 text-primary" /> Alert Stream
          </h3>
          <div className="flex gap-1">
            {(['all', 'high', 'medium', 'low'] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-2 py-1 text-[10px] rounded uppercase font-mono border transition ${
                  filter === f ? 'border-primary text-primary bg-primary/10' : 'border-border text-muted-foreground hover:text-foreground'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
        <div className="max-h-96 overflow-auto space-y-2">
          {filtered.length === 0 ? (
            <p className="text-xs text-muted-foreground py-6 text-center">No alerts to display.</p>
          ) : (
            filtered.map(a => (
              <div key={a.id} className={`border-l-2 pl-3 py-2 rounded-r ${sevColor[a.severity]}`}>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-mono uppercase">{a.severity} • {a.category}</span>
                  <span className="text-[10px] text-muted-foreground font-mono">
                    {new Date(a.ts).toLocaleTimeString()} • {a.source}
                  </span>
                </div>
                <p className="text-xs text-foreground mt-1 break-all">{a.message}</p>
              </div>
            ))
          )}
        </div>
      </div>

      <p className="text-[10px] text-muted-foreground text-center">
        IDS aggregates live data from Packet Analyzer and Log Analyzer modules. Logs analyzed: {logs.length}
      </p>
    </div>
  );
}
