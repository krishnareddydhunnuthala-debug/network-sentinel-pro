import { Shield, AlertTriangle, Activity, Wifi, Clock, TrendingUp } from 'lucide-react';

interface OverviewProps {
  stats: {
    logsAnalyzed: number;
    threatsDetected: number;
    portsScanned: number;
    packetsInspected: number;
  };
}

export default function OverviewModule({ stats }: OverviewProps) {
  const cards = [
    { label: 'Logs Analyzed', value: stats.logsAnalyzed, icon: Activity, color: 'text-primary' },
    { label: 'Threats Detected', value: stats.threatsDetected, icon: AlertTriangle, color: 'text-destructive' },
    { label: 'Ports Scanned', value: stats.portsScanned, icon: Wifi, color: 'text-warning' },
    { label: 'Packets Inspected', value: stats.packetsInspected, icon: Shield, color: 'text-primary' },
  ];

  const systemStatus = [
    { label: 'Log Processor', status: 'Online', color: 'bg-primary' },
    { label: 'Port Scanner', status: 'Online', color: 'bg-primary' },
    { label: 'Packet Engine', status: 'Online', color: 'bg-primary' },
    { label: 'Threat Intel API', status: 'Live', color: 'bg-primary' },
    { label: 'Web Scraper', status: 'Online', color: 'bg-primary' },
    { label: 'Report Generator', status: 'Online', color: 'bg-primary' },
  ];

  const hasActivity = stats.logsAnalyzed > 0 || stats.threatsDetected > 0 || stats.portsScanned > 0 || stats.packetsInspected > 0;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground cyber-glow-text">System Overview</h2>
          <p className="text-muted-foreground text-sm">Network Activity Intelligence Dashboard</p>
        </div>
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-card border border-border rounded-lg">
          <Clock className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-xs text-muted-foreground font-mono">{new Date().toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-6">
        {cards.map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="cyber-card p-4 md:p-5 group hover:border-primary/30 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] md:text-xs text-muted-foreground uppercase tracking-wider">{c.label}</span>
                <Icon className={`w-4 h-4 ${c.color} opacity-60 group-hover:opacity-100 transition`} />
              </div>
              <p className={`text-2xl md:text-3xl font-bold font-mono ${c.color}`}>{c.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-6">
        <div className="cyber-card p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            System Status
          </h3>
          <div className="space-y-2.5">
            {systemStatus.map(s => (
              <div key={s.label} className="flex items-center justify-between py-1">
                <span className="text-sm text-muted-foreground">{s.label}</span>
                <div className="flex items-center gap-2">
                  <div className={`w-1.5 h-1.5 rounded-full ${s.color} animate-pulse`} />
                  <span className="text-xs font-mono text-foreground">{s.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="cyber-card p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" />
            Session Activity
          </h3>
          {hasActivity ? (
            <div className="space-y-3 text-sm">
              <p className="text-muted-foreground">Live counters from your active investigation:</p>
              <ul className="space-y-2 text-foreground">
                {stats.logsAnalyzed > 0 && <li>• <span className="font-mono text-primary">{stats.logsAnalyzed}</span> log entries parsed</li>}
                {stats.threatsDetected > 0 && <li>• <span className="font-mono text-destructive">{stats.threatsDetected}</span> threats detected</li>}
                {stats.portsScanned > 0 && <li>• <span className="font-mono text-warning">{stats.portsScanned}</span> ports probed</li>}
                {stats.packetsInspected > 0 && <li>• <span className="font-mono text-primary">{stats.packetsInspected}</span> packets inspected</li>}
              </ul>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              No data yet — open any module on the left to start collecting real-time telemetry.
              Counters here update live as you analyze logs, scan ports, capture packets, and look up IPs.
            </p>
          )}
        </div>
      </div>

      <div className="cyber-card p-5 md:p-6">
        <h3 className="text-sm font-semibold text-foreground mb-4">Quick Start Guide</h3>
        <div className="grid md:grid-cols-3 gap-3 text-sm text-muted-foreground">
          {[
            { step: '01', text: 'Upload your real server logs in **Log Analyzer** to detect suspicious IPs' },
            { step: '02', text: 'Probe open ports on a target host with **Network Scanner**' },
            { step: '03', text: 'Inspect this session\'s real network traffic in **Packet Analyzer**' },
            { step: '04', text: 'Look up live geolocation and ASN data in **Threat Intel**' },
            { step: '05', text: 'Extract structured data from any URL with the **Web Scraper**' },
            { step: '06', text: 'Generate a downloadable report from your findings in **Reports**' },
          ].map(item => (
            <div key={item.step} className="flex gap-3 p-3 rounded-lg bg-background/50 border border-border/30">
              <span className="text-primary font-mono font-bold">{item.step}</span>
              <span className="text-xs leading-relaxed" dangerouslySetInnerHTML={{
                __html: item.text.replace(/\*\*(.*?)\*\*/g, '<strong class="text-foreground">$1</strong>')
              }} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
