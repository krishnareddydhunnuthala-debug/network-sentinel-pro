import { useState, useCallback, useEffect, useRef } from 'react';
import { Play, Square, AlertTriangle, Eye, Trash2, Wifi } from 'lucide-react';
import { analyzePacketStream, packetFromResourceTiming, type PacketData } from '@/lib/cyberUtils';

interface PacketAnalyzerProps {
  onCapture: (packets: PacketData[]) => void;
}

const MAX_PACKETS = 500;

export default function PacketAnalyzerModule({ onCapture }: PacketAnalyzerProps) {
  const [packets, setPackets] = useState<PacketData[]>([]);
  const [isLive, setIsLive] = useState(false);
  const [selectedPacket, setSelectedPacket] = useState<PacketData | null>(null);
  const [filter, setFilter] = useState<'all' | 'anomalies'>('all');
  const [autoScroll, setAutoScroll] = useState(true);
  const [capturedCount, setCapturedCount] = useState(0);
  const observerRef = useRef<PerformanceObserver | null>(null);
  const counterRef = useRef(0);
  const captureStartedAtRef = useRef(0);
  const seenKeysRef = useRef<Set<string>>(new Set());
  const listRef = useRef<HTMLDivElement>(null);

  const stopCapture = useCallback(() => {
    if (observerRef.current) {
      observerRef.current.disconnect();
      observerRef.current = null;
    }
    setIsLive(false);
  }, []);

  const clearPackets = useCallback(() => {
    stopCapture();
    setPackets([]);
    setSelectedPacket(null);
    counterRef.current = 0;
    captureStartedAtRef.current = 0;
    seenKeysRef.current.clear();
    setCapturedCount(0);
    onCapture([]);
  }, [onCapture, stopCapture]);

  const ingestEntries = useCallback((entries: PerformanceResourceTiming[]) => {
    if (!entries.length || !captureStartedAtRef.current) return;

    const fresh: PacketData[] = [];

    for (const entry of entries) {
      const absoluteStart = performance.timeOrigin + entry.startTime;
      if (absoluteStart < captureStartedAtRef.current) continue;

      const key = `${entry.name}|${entry.startTime}|${entry.responseEnd}`;
      if (seenKeysRef.current.has(key)) continue;
      if (entry.name.includes('/functions/v1/port-scanner')) continue;

      seenKeysRef.current.add(key);
      counterRef.current += 1;
      fresh.push(packetFromResourceTiming(entry, counterRef.current));
    }

    if (!fresh.length) return;

    setCapturedCount(previous => previous + fresh.length);
    setPackets(previous => {
      const combined = [...fresh.reverse(), ...previous];
      const analyzed = analyzePacketStream(combined).slice(0, MAX_PACKETS);
      onCapture(analyzed);
      return analyzed;
    });
  }, [onCapture]);

  const startCapture = useCallback(() => {
    clearPackets();
    captureStartedAtRef.current = Date.now();
    setIsLive(true);

    const observer = new PerformanceObserver(list => {
      ingestEntries(list.getEntries() as PerformanceResourceTiming[]);
    });

    // buffered:true is safe here because we discard entries older than the current capture start time.
    observer.observe({ type: 'resource', buffered: true });
    observerRef.current = observer;
  }, [clearPackets, ingestEntries]);

  useEffect(() => {
    if (autoScroll && listRef.current) {
      listRef.current.scrollTop = 0;
    }
  }, [packets, autoScroll]);

  useEffect(() => () => {
    if (observerRef.current) observerRef.current.disconnect();
  }, []);

  const displayed = filter === 'anomalies' ? packets.filter(packet => packet.anomaly) : packets;
  const anomalyCount = packets.filter(packet => packet.anomaly).length;
  const detectionRate = packets.length ? ((anomalyCount / packets.length) * 100).toFixed(1) : '0.0';
  const uniqueDestinations = new Set(packets.map(packet => packet.destination)).size;

  return (
    <div>
      <div className="flex items-start justify-between mb-6 gap-3 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-1 cyber-glow-text">Packet Analyzer</h2>
          <p className="text-muted-foreground text-sm">Live capture of real network requests made after you press start, inspected continuously for anomalies</p>
        </div>
        {isLive && (
          <div className="flex items-center gap-2 text-xs bg-card border border-primary/40 rounded-md px-3 py-1.5">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
            </span>
            <span className="text-primary font-mono font-semibold">LIVE CAPTURE</span>
          </div>
        )}
      </div>

      <div className="cyber-card p-5 mb-4">
        <div className="flex items-center gap-3 flex-wrap">
          {!isLive ? (
            <button onClick={startCapture} className="px-6 py-2.5 bg-primary text-primary-foreground rounded-md font-medium text-sm hover:bg-primary/90 transition flex items-center gap-2">
              <Play className="w-4 h-4" /> Start Live Capture
            </button>
          ) : (
            <button onClick={stopCapture} className="px-6 py-2.5 bg-destructive text-destructive-foreground rounded-md font-medium text-sm hover:bg-destructive/90 transition flex items-center gap-2">
              <Square className="w-4 h-4" /> Stop Capture
            </button>
          )}
          <button
            onClick={clearPackets}
            disabled={packets.length === 0 && !isLive && capturedCount === 0}
            className="px-4 py-2.5 text-sm text-muted-foreground hover:text-foreground border border-border rounded-md hover:bg-secondary disabled:opacity-40 transition flex items-center gap-2"
          >
            <Trash2 className="w-4 h-4" /> Clear
          </button>
          <label className="flex items-center gap-2 text-xs text-muted-foreground ml-auto cursor-pointer select-none">
            <input
              type="checkbox"
              checked={autoScroll}
              onChange={event => setAutoScroll(event.target.checked)}
              className="accent-primary"
            />
            Auto-scroll
          </label>
        </div>
        <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1.5">
          <Wifi className="w-3.5 h-3.5" />
          Captures real browser network activity from this moment forward only, so old session traffic no longer appears before you start.
        </p>
      </div>

      {packets.length > 0 ? (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Total Packets</p>
              <p className="text-2xl font-bold font-mono text-primary">{packets.length}</p>
            </div>
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Anomalies</p>
              <p className="text-2xl font-bold font-mono text-destructive">{anomalyCount}</p>
            </div>
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Detection Rate</p>
              <p className="text-2xl font-bold font-mono text-warning">{detectionRate}%</p>
            </div>
            <div className="cyber-card p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Unique Destinations</p>
              <p className="text-2xl font-bold font-mono text-foreground">{uniqueDestinations}</p>
            </div>
          </div>

          <div className="flex gap-2 mb-4">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition ${filter === 'all' ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground'}`}
            >
              All Packets ({packets.length})
            </button>
            <button
              onClick={() => setFilter('anomalies')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1 ${filter === 'anomalies' ? 'bg-destructive/15 text-destructive' : 'text-muted-foreground hover:text-foreground'}`}
            >
              <AlertTriangle className="w-3 h-3" />
              Anomalies ({anomalyCount})
            </button>
          </div>

          <div className="cyber-card p-5">
            <div ref={listRef} className="overflow-auto max-h-80">
              <table className="w-full text-xs font-mono">
                <thead className="sticky top-0 bg-card">
                  <tr className="border-b border-border text-muted-foreground text-left">
                    <th className="pb-2 pr-3">#</th>
                    <th className="pb-2 pr-3">Time</th>
                    <th className="pb-2 pr-3">Destination</th>
                    <th className="pb-2 pr-3">Proto</th>
                    <th className="pb-2 pr-3">Port</th>
                    <th className="pb-2 pr-3">Severity</th>
                    <th className="pb-2 pr-3">Size</th>
                    <th className="pb-2 pr-3">Finding</th>
                    <th className="pb-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {displayed.map(packet => (
                    <tr key={packet.id} className={`border-b border-border/30 transition ${packet.anomaly ? 'bg-destructive/5 hover:bg-destructive/10' : 'hover:bg-secondary/30'}`}>
                      <td className="py-1.5 pr-3 text-muted-foreground">{packet.id}</td>
                      <td className="py-1.5 pr-3 text-muted-foreground">{new Date(packet.timestamp).toLocaleTimeString()}</td>
                      <td className="py-1.5 pr-3 text-foreground truncate max-w-[200px]">{packet.destination}</td>
                      <td className="py-1.5 pr-3">{packet.protocol}</td>
                      <td className="py-1.5 pr-3">{packet.destinationPort || '—'}</td>
                      <td className="py-1.5 pr-3">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                          packet.severity === 'high' ? 'bg-destructive/15 text-destructive' :
                          packet.severity === 'medium' ? 'bg-warning/15 text-warning' :
                          packet.severity === 'low' ? 'bg-primary/15 text-primary' :
                          'bg-secondary text-muted-foreground'
                        }`}>{(packet.severity || 'info').toUpperCase()}</span>
                      </td>
                      <td className="py-1.5 pr-3">{packet.size}B</td>
                      <td className="py-1.5 pr-3">
                        {packet.anomaly ? (
                          <div className="space-y-0.5">
                            <span className="text-destructive block">{packet.anomaly}</span>
                            <span className="text-muted-foreground text-[11px]">{packet.category}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground">{packet.category || 'Normal Traffic'}</span>
                        )}
                      </td>
                      <td className="py-1.5">
                        <button onClick={() => setSelectedPacket(packet)} className="text-muted-foreground hover:text-primary">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {displayed.length === 0 && (
                <p className="text-center text-muted-foreground text-sm py-8">No packets match this filter</p>
              )}
            </div>
            <p className="text-[11px] text-muted-foreground mt-3">
              Captured {capturedCount} live requests in this run. Buffer keeps the latest {MAX_PACKETS} entries.
            </p>
          </div>

          {selectedPacket && (
            <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setSelectedPacket(null)}>
              <div className="cyber-card p-6 max-w-lg w-full" onClick={event => event.stopPropagation()}>
                <h3 className="text-sm font-semibold text-foreground mb-4">Packet #{selectedPacket.id} Details</h3>
                <div className="space-y-2 text-sm font-mono">
                  <div className="flex justify-between"><span className="text-muted-foreground">Time:</span><span className="text-foreground">{new Date(selectedPacket.timestamp).toLocaleTimeString()}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Source:</span><span className="text-foreground">{selectedPacket.source}</span></div>
                  <div className="flex justify-between gap-3"><span className="text-muted-foreground shrink-0">Dest:</span><span className="text-foreground text-right break-all">{selectedPacket.destination}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Protocol:</span><span className="text-foreground">{selectedPacket.protocol}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Destination Port:</span><span className="text-foreground">{selectedPacket.destinationPort || '—'}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Size:</span><span className="text-foreground">{selectedPacket.size} bytes</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Category:</span><span className="text-foreground">{selectedPacket.category || 'Normal Traffic'}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Severity:</span><span className="text-foreground uppercase">{selectedPacket.severity || 'info'}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Flags:</span><span className="text-foreground">{selectedPacket.flags.join(', ') || '—'}</span></div>
                  {selectedPacket.flowLabel && (
                    <div className="flex justify-between"><span className="text-muted-foreground">Flow:</span><span className="text-foreground">{selectedPacket.flowLabel}</span></div>
                  )}
                  <div className="mt-3">
                    <span className="text-muted-foreground block mb-1">Full URL:</span>
                    <div className={`p-3 rounded bg-background border border-border text-xs break-all ${selectedPacket.anomaly ? 'text-destructive' : 'text-foreground'}`}>
                      {selectedPacket.payload}
                    </div>
                  </div>
                  {!!selectedPacket.matchedRules?.length && (
                    <div className="mt-3">
                      <span className="text-muted-foreground block mb-1">Detection Rules:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedPacket.matchedRules.map(rule => (
                          <span key={rule} className="text-xs px-2 py-0.5 rounded bg-secondary text-secondary-foreground font-mono">{rule}</span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedPacket.anomaly && (
                    <div className="mt-2 p-2 bg-destructive/10 rounded border border-destructive/30 text-destructive text-xs flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" />
                      {selectedPacket.anomaly}
                    </div>
                  )}
                </div>
                <button onClick={() => setSelectedPacket(null)} className="mt-4 w-full py-2 bg-secondary text-secondary-foreground rounded-md text-sm hover:bg-secondary/80 transition">Close</button>
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="cyber-card p-8 text-center text-muted-foreground">
          {isLive ? 'Waiting for live network activity…' : 'Start live capture to inspect real browser traffic.'}
        </div>
      )}
    </div>
  );
}
